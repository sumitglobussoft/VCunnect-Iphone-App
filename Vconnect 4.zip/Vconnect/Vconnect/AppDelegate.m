//
//  AppDelegate.m
//  Vconnect
//
//  Created by Sumit on 09/01/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import "AppDelegate.h"
#import "Reachability.h"
#import "LocationHelper.h"
#import "XMPP.h"
#import "XMPPLogging.h"
#import "XMPPReconnect.h"
#import "XMPPCapabilitiesCoreDataStorage.h"
#import "XMPPRosterCoreDataStorage.h"
#import "XMPPvCardAvatarModule.h"
#import "XMPPvCardCoreDataStorage.h"
#import "SingletonClass.h"
#import "LocationHelper.h"

#import "DDLog.h"
#import "DDTTYLogger.h"
@class MessageDetailViewController;
#if DEBUG
static const int ddLogLevel = LOG_LEVEL_VERBOSE;
#else
static const int ddLogLevel = LOG_LEVEL_INFO;
#endif

NSString *const kXMPPmyJID = @"kXMPPmyJID";
NSString *const kXMPPmyPassword = @"kXMPPmyPassword";


@interface AppDelegate (){

}

- (void)setupStream;
- (void)teardownStream;

- (void)goOnline;
- (void)goOffline;

@end


@implementation AppDelegate

@synthesize xmppStream;
@synthesize xmppReconnect;
@synthesize xmppRoster;
@synthesize xmppRosterStorage;
@synthesize xmppvCardTempModule;
@synthesize xmppvCardAvatarModule;
@synthesize xmppCapabilities;
@synthesize xmppCapabilitiesStorage;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.

    [self reacheability];
    
    
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
    {
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
        [[UIApplication sharedApplication] registerForRemoteNotifications];
    }
    else
    {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:
         (UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert)];
    }

    
    [[LocationHelper sharedObject]startLocationUpdatingWithBlock:^(CLLocation *newLocation, CLLocation *oldLocation, NSError *error)
     {
//                 [self updateLocation];
     }];


  
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
   
    NSString *str=    [[NSUserDefaults standardUserDefaults] valueForKey:@"isLogin"];
    
    if ([str isEqualToString:@"NO" ] || str == nil) {
       
        self.viewController=[[AppDelegateFirstVC alloc] init];
        
        self.navigationController=[[UINavigationController alloc] initWithRootViewController:self.viewController];
        self.navigationController.delegate=self;
        self.navigationController.navigationBar.backgroundColor=[UIColor colorWithRed:17.0/255.0 green:147.0/255.0 blue:132.0/255.0 alpha:1.0];
        self.navigationController.navigationBarHidden=YES;

        self.window.rootViewController = self.navigationController;
    }
    else{
        ProfileViewController *prof = [[ProfileViewController alloc]init];
        prof.title= @"Profile";
    
        FirstVC *firstVC=[[FirstVC alloc] init];
        firstVC.title=@"Activity";
        
        CalendarViewController *calendar = [[CalendarViewController alloc]init];
        calendar.title=@"Calendar";
        
        GroupViewController *group = [[GroupViewController alloc]init];
        group.title=@"Groups";
        
        MessagesViewController *message = [[MessagesViewController alloc]init];
        message.title = @"Message";
        
        RefreshViewController *refresh = [[RefreshViewController alloc]init];
        refresh.title = @"Refresh";
        
        InterestViewController *interest = [[InterestViewController alloc]init];
        interest.title=@"Interests";
        
        SettingsViewController *settings = [[SettingsViewController alloc]init];
        settings.title = @"Settings";
        
        HomeVC *homeVC=[[HomeVC alloc] init];
        homeVC.viewControllers = @[prof,firstVC,calendar,group,message,refresh,interest,settings];
        
        self.navigationController=[[UINavigationController alloc] initWithRootViewController:homeVC];
        self.navigationController.delegate=self;
        self.navigationController.navigationBar.backgroundColor=[UIColor colorWithRed:17.0/255.0 green:147.0/255.0 blue:132.0/255.0 alpha:1.0];
        self.navigationController.navigationBarHidden=YES;
        
        self.window.rootViewController=self.navigationController ;
    }
    [self.window makeKeyAndVisible];
    [ self setupStream ];
    return YES;
}
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSLog(@"notification %@",userInfo);
    
}



#pragma Reacheability

-(void)reacheability
{
    // NSLog(@"Rechability");
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    [reachability startNotifier];
    
    NetworkStatus status = [reachability currentReachabilityStatus];
    BOOL networkStatus = NO;
    
    if(status == NotReachable)
    {
        // NSLog(@"stringgk////");
        networkStatus = NO;
    }
    else if (status == ReachableViaWiFi)
    {
        // NSLog(@"reachable");
        networkStatus = YES;
        
    }
    else if (status == ReachableViaWWAN)
    {
        //3G
        networkStatus = YES;
    }
    else
    {
        networkStatus = NO;
    }
    // Do any additional setup after loading the view.
    
    [[NSUserDefaults standardUserDefaults] setBool:networkStatus forKey:@"CurrentNetworkStatus"];
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    
    
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
#if TARGET_IPHONE_SIMULATOR
    DDLogError(@"The iPhone simulator does not process background network traffic. "
               @"Inbound traffic is queued until the keepAliveTimeout:handler: fires.");
#endif
    
    if ([application respondsToSelector:@selector(setKeepAliveTimeout:handler:)])
    {
        [application setKeepAliveTimeout:600 handler:^{
            
            DDLogVerbose(@"KeepAliveHandler");
            
                // Do other keep alive stuff here.
        }];
    }

}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    [self teardownStream];

}




- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation {
    // attempt to extract a token from the url
    //return [FBSession.activeSession handleOpenURL:url];
    
    NSLog(@"url is %@",url);
    
//    [PFFacebookUtils handleOpenURL:url];
//    
////    [FBAppCall handleOpenURL:url sourceApplication:sourceApplication fallbackHandler:^(FBAppCall *call) {
//        NSString *accessToken = call.accessTokenData.accessToken;
//        [[NSUserDefaults standardUserDefaults] setObject:accessToken forKey:@"Facebook Access Token"];
//        NSLog(@"Access Token = %@",call.accessTokenData.accessToken);
//        NSLog(@"App Link Data = %@",call.appLinkData);
//        NSLog(@"call == %@",call);
//        
//        if (call.appLinkData && call.appLinkData.targetURL) {
//            
//            //[self openSessionWithLoginUI:8 withParams:nil];
//            //            [[NSNotificationCenter defaultCenter] postNotificationName:FacebookRequestNotification object:call.appLinkData.targetURL];
//        }
    
//    }];
    return YES;
}

+(AppDelegate *)sharedAppDelegate
{
    return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    NSLog(@"Url== %@", url);
//    return [FBSession.activeSession handleOpenURL:url];
    return YES;
}

-(void) showHUDLoadingView:(NSString *)strTitle
{
    HUD = [[MBProgressHUD alloc] initWithView:self.window];
    [self.window addSubview:HUD];
    //HUD.delegate = self;
    //HUD.labelText = [strTitle isEqualToString:@""] ? @"Loading...":strTitle;
    HUD.detailsLabelText=[strTitle isEqualToString:@""] ? @"Loading...":strTitle;
    [HUD show:YES];
}

-(void) hideHUDLoadingView
{
    [HUD removeFromSuperview];
}


-(void)showToastMessage:(NSString *)message
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.window
                                              animated:YES];
    
    // Configure for text only and offset down
    hud.mode = MBProgressHUDModeText;
    hud.detailsLabelText = message;
    hud.margin = 10.f;
    hud.yOffset = 150.f;
    hud.removeFromSuperViewOnHide = YES;
    [hud hide:YES afterDelay:3.0];
}


#pragma mark- Appearence
-(NSString *)appearanceBodyType:(NSString *)value{
    NSString * bodyType=@"";
    
    int val= value.intValue;
    if (val==0) {
        bodyType=@"Unfilled yet";
    }
    else if(val==1)
    {
        bodyType=@"Average";
    }
    else if(val==2)
    {
        bodyType=@"A few extra pounds";
    }
    else if(val==3)
    {
        bodyType=@"Slim";
    }
    else if(val==4)
    {
        bodyType=@"Athletic";
    }
    else if(val==5)
    {
        bodyType=@"Muscular";
    }
    else
    {
        bodyType=@"Big and beautiful";
    }
    
    return bodyType;
}

-(NSString *)appearanceHairColor:(NSString *)value{
    NSString * hairColor=@"";
    
    int val= value.intValue;
    if (val==0) {
        hairColor=@"Unfilled yet";
    }
    else if(val==1)
    {
        hairColor=@"Black";
    }
    else if(val==2)
    {
        hairColor=@"Brown";
    }
    else if(val==3)
    {
        hairColor=@"Red";
    }
    else if(val==4)
    {
        hairColor=@"Grey";
    }
    else if(val==5)
    {
        hairColor=@"White";
    }
    else if(val==6)
    {
        hairColor=@"Shaved";
    }
    else if(val==7)
    {
        hairColor=@"Dyed";
    }
    else
    {
        hairColor=@"Bald";
    }
    
    
    return hairColor;
    
}
-(NSString *)appearanceKids:(NSString *)value{
    int val= value.intValue;
    NSString * kids=@"";
    if (val==0) {
        kids=@"Unfilled yet";
    }
    else if(val==1)
    {
        kids=@"No, Never";
    }
    else if(val==2)
    {
        kids=@"Someday";
    }
    else if(val==3)
    {
        kids=@"Already Have";
    }
    else
    {
        kids=@"Empty nest";
    }
    return kids;
}

-(NSString *)appearanceEyeColor:(NSString *)value{
    NSString * eyeColor=@"";
    
    int val= value.intValue;
    if (val==0) {
        eyeColor=@"others";
    }
    else if(val==1)
    {
        eyeColor=@"Brown";
    }
    else if(val==2)
    {
        eyeColor=@"Grey";
    }
    else if(val==3)
    {
        eyeColor=@"Green";
    }
    else if(val==4)
    {
        eyeColor=@"Blue";
    }
    else if(val==5)
    {
        eyeColor=@"Hazel";
    }
    else
    {
        eyeColor=@"Other";
    }
    
    return eyeColor;
    
}
-(NSString *)appearanceIncome:(NSString *)value{
    int val=value.intValue;
    NSString * income=@"";
    if (val==0) {
        income=@"Unfilled yet";
    }
    else if(val==1)
    {
        income=@"Low";
    }
    else if(val==2)
    {
        income=@"Average";
    }
    else
    {
        income=@"High";
    }
    return  income;
}

-(NSString *)appearanceLving:(NSString *)value{
    NSString * living=@"";
    int val= value.intValue;
    if (val==0) {
        living=@"Unfilled yet";
    }
    else if(val==1)
    {
        living=@"With Parents";
    }
    else if(val==2)
    {
        living=@"With Roomates";
    }
    else if(val==3)
    {
        living=@"Student Residence";
    }
    else if(val==4)
    {
        living=@"With Partner";
    }
    else{
        living=@"Alone";
    }
    return  living;
}
-(NSString *)appearanceSmoking:(NSString *)value{
    int val= value.intValue;
    NSString * smoking=@"";
    if (val==0) {
        smoking=@"Unfilled yet";
    }
    else if (val==1){
        smoking=@"No";
    }
    else if (val==2)
    {
        smoking=@"No, Never";
    }
    else if (val==3)
    {
        smoking=@"Yes";
    }
    else if (val==4)
    {
        smoking=@"Social";
    }
    else
    {
        smoking=@"Chain Smoker, Oxygen is overrated";
    }
    
    return smoking;
}

-(NSString *)appearanceDrinking:(NSString *)value{
    int val=value.intValue;
    NSString * drinking=@"";
    if (val==0) {
        drinking=@"Unfilled yet";
        
    }
    else if (val==1)
    {
        drinking=@"No";
        
    }
    else if (val==3)
    {
        drinking=@"With Company";
    }
    else if(val==2){
        drinking=@"No, Never";
    }
    else{
        drinking=@"Yes, Please";
    }
    return drinking;
}

-(NSString *)appearanceEducation:(NSString *)value{
    int val=value.intValue;
    NSString * edu=@"";
    if (val==0) {
        edu=@"Unfilled yet";
        
    }
    else if (val==1)
    {
        edu=@"School only";
        
    }
    else if (val==3)
    {
        edu=@"Trade/Technical";
    }
    else if(val==2){
        edu=@"College/University";
    }
    else{
        edu=@"Advanced Degree";
    }
    return edu;
}
-(NSString *)appearanceRelationShip:(NSString *)value{
    int val=value.intValue;
    NSString * relation=@"";
    if (val==0) {
        relation=@"Unfilled yet";
        
    }
    else if (val==1)
    {
        relation=@"Single";
        
    }
    else if (val==3)
    {
        relation=@"Taken";
    }
    else{
        relation=@"Open";
    }
    return relation;
}

-(NSString * )appearancesexuality:(NSString *)value
{
    int val=value.intValue;
    NSString * sex=@"";
    if (val==0) {
        sex=@"Unfilled yet";
        
    }
    else if (val==1)
    {
        sex=@"Straight";
        
    }
    else if (val==3)
    {
        sex=@"Bisexual";
    }
    else if(val==2){
        sex=@"Open Minded";
    }
    else if(val==4){
        sex=@"Gay";
    }
    else{
        sex=@"Lesbian";
    }
    return sex;
    
}

- (void)teardownStream
{
    [xmppStream removeDelegate:self];
    [xmppRoster removeDelegate:self];
    
    [xmppReconnect         deactivate];
    [xmppRoster            deactivate];
    [xmppvCardTempModule   deactivate];
    [xmppvCardAvatarModule deactivate];
    [xmppCapabilities      deactivate];
    
    [xmppStream disconnect];
    
    xmppStream = nil;
    xmppReconnect = nil;
    xmppRoster = nil;
    xmppRosterStorage = nil;
    xmppvCardStorage = nil;
    xmppvCardTempModule = nil;
    xmppvCardAvatarModule = nil;
    xmppCapabilities = nil;
    xmppCapabilitiesStorage = nil;
}

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark Core Data
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
- (NSManagedObjectContext *)managedObjectContext_roster
{
    return [xmppRosterStorage mainThreadManagedObjectContext];
}

- (NSManagedObjectContext *)managedObjectContext_capabilities
{
    return [xmppCapabilitiesStorage mainThreadManagedObjectContext];
}

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark Private
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (void)setupStream
{
    NSAssert(xmppStream == nil, @"Method setupStream invoked multiple times");
    
        // Setup xmpp stream
        //
        // The XMPPStream is the base class for all activity.
        // Everything else plugs into the xmppStream, such as modules/extensions and delegates.
    
    xmppStream = [[XMPPStream alloc] init];
    
#if !TARGET_IPHONE_SIMULATOR
    {
            // Want xmpp to run in the background?
            //
            // P.S. - The simulator doesn't support backgrounding yet.
            //        When you try to set the associated property on the simulator, it simply fails.
            //        And when you background an app on the simulator,
            //        it just queues network traffic til the app is foregrounded again.
            //        We are patiently waiting for a fix from Apple.
            //        If you do enableBackgroundingOnSocket on the simulator,
            //        you will simply see an error message from the xmpp stack when it fails to set the property.
        
        xmppStream.enableBackgroundingOnSocket = YES;
    }
#endif
    
        // Setup reconnect
        //
        // The XMPPReconnect module monitors for "accidental disconnections" and
        // automatically reconnects the stream for you.
        // There's a bunch more information in the XMPPReconnect header file.
    
    xmppReconnect = [[XMPPReconnect alloc] init];
    
        // Setup roster
        //
        // The XMPPRoster handles the xmpp protocol stuff related to the roster.
        // The storage for the roster is abstracted.
        // So you can use any storage mechanism you want.
        // You can store it all in memory, or use core data and store it on disk, or use core data with an in-memory store,
        // or setup your own using raw SQLite, or create your own storage mechanism.
        // You can do it however you like! It's your application.
        // But you do need to provide the roster with some storage facility.
    
    xmppRosterStorage = [[XMPPRosterCoreDataStorage alloc] init];
        //	xmppRosterStorage = [[XMPPRosterCoreDataStorage alloc] initWithInMemoryStore];
    
    xmppRoster = [[XMPPRoster alloc] initWithRosterStorage:xmppRosterStorage];
    
    xmppRoster.autoFetchRoster = YES;
    xmppRoster.autoAcceptKnownPresenceSubscriptionRequests = YES;
    
        // Setup vCard support
        //
        // The vCard Avatar module works in conjuction with the standard vCard Temp module to download user avatars.
        // The XMPPRoster will automatically integrate with XMPPvCardAvatarModule to cache roster photos in the roster.
    
    xmppvCardStorage = [XMPPvCardCoreDataStorage sharedInstance];
    xmppvCardTempModule = [[XMPPvCardTempModule alloc] initWithvCardStorage:xmppvCardStorage];
    
    xmppvCardAvatarModule = [[XMPPvCardAvatarModule alloc] initWithvCardTempModule:xmppvCardTempModule];
    
        // Setup capabilities
        //
        // The XMPPCapabilities module handles all the complex hashing of the caps protocol (XEP-0115).
        // Basically, when other clients broadcast their presence on the network
        // they include information about what capabilities their client supports (audio, video, file transfer, etc).
        // But as you can imagine, this list starts to get pretty big.
        // This is where the hashing stuff comes into play.
        // Most people running the same version of the same client are going to have the same list of capabilities.
        // So the protocol defines a standardized way to hash the list of capabilities.
        // Clients then broadcast the tiny hash instead of the big list.
        // The XMPPCapabilities protocol automatically handles figuring out what these hashes mean,
        // and also persistently storing the hashes so lookups aren't needed in the future.
        //
        // Similarly to the roster, the storage of the module is abstracted.
        // You are strongly encouraged to persist caps information across sessions.
        //
        // The XMPPCapabilitiesCoreDataStorage is an ideal solution.
        // It can also be shared amongst multiple streams to further reduce hash lookups.
    
    xmppCapabilitiesStorage = [XMPPCapabilitiesCoreDataStorage sharedInstance];
    xmppCapabilities = [[XMPPCapabilities alloc] initWithCapabilitiesStorage:xmppCapabilitiesStorage];
    
    xmppCapabilities.autoFetchHashedCapabilities = YES;
    xmppCapabilities.autoFetchNonHashedCapabilities = NO;
    
        // Activate xmpp modules
    
    [xmppReconnect         activate:xmppStream];
    [xmppRoster            activate:xmppStream];
    [xmppvCardTempModule   activate:xmppStream];
    [xmppvCardAvatarModule activate:xmppStream];
    [xmppCapabilities      activate:xmppStream];
    
        // Add ourself as a delegate to anything we may be interested in
    
    [xmppStream addDelegate:self delegateQueue:dispatch_get_main_queue()];
    [xmppRoster addDelegate:self delegateQueue:dispatch_get_main_queue()];
    
        // Optional:
        //
        // Replace me with the proper domain and port.
        // The example below is setup for a typical google talk account.
        //
        // If you don't supply a hostName, then it will be automatically resolved using the JID (below).
        // For example, if you supply a JID like 'user@quack.com/rsrc'
        // then the xmpp framework will follow the xmpp specification, and do a SRV lookup for quack.com.
        //
        // If you don't specify a hostPort, then the default (5222) will be used.
    
        //    [xmppStream setHostName:@"192.168.6.125"];
        //    [xmppStream setHostPort:5820];
    [xmppStream setHostName:@"takadating.com"];
    [xmppStream setHostPort:5222];
    
        // You may need to alter these settings depending on the server you're connecting to
    customCertEvaluation = YES;
}
- (void)goOnline
{
    XMPPPresence *presence = [XMPPPresence presence]; // type="available" is implicit
    
    NSString *domain = [xmppStream.myJID domain];
    
        //Google set their presence priority to 24, so we do the same to be compatible.
    
    if ([domain isEqualToString:@"glb-120-pc"]) {// me edited
        NSXMLElement *priority = [NSXMLElement elementWithName:@"priority" stringValue:@"24"];
        [presence addChild:priority];
    }
    /* if([domain isEqualToString:@"takadating.com"]
     || [domain isEqualToString:@"takadating.com"]
     || [domain isEqualToString:@"takadating.com"])
     {
     NSXMLElement *priority = [NSXMLElement elementWithName:@"priority" stringValue:@"24"];
     [presence addChild:priority];
     }*/
    
    [[self xmppStream] sendElement:presence];
}

- (void)goOffline
{
    XMPPPresence *presence = [XMPPPresence presenceWithType:@"unavailable"];
    
    [[self xmppStream] sendElement:presence];
}

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark Connect/disconnect
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
- (BOOL)connect
{
    if (![xmppStream isDisconnected]) {
        return YES;
    }
    
    NSString *myJID = [[NSUserDefaults standardUserDefaults] stringForKey:kXMPPmyJID];
    NSString *myPassword = [[NSUserDefaults standardUserDefaults] stringForKey:kXMPPmyPassword];
    
        //
        // If you don't want to use the Settings view to set the JID,
        // uncomment the section below to hard code a JID and password.
        //
        // myJID = @"user@gmail.com/xmppframework";
        // myPassword = @"";
    
    if (myJID == nil || myPassword == nil) {
        return NO;
    }
    
    [xmppStream setMyJID:[XMPPJID jidWithString:myJID]];
    password = myPassword;
    
    NSError *error = nil;
    if (![xmppStream connectWithTimeout:XMPPStreamTimeoutNone error:&error])
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error connecting"
                                                            message:@"See console for error details."
                                                           delegate:nil
                                                  cancelButtonTitle:@"Ok"
                                                  otherButtonTitles:nil];
        [alertView show];
        
        DDLogError(@"Error connecting: %@", error);
        
        return NO;
    }
    
    return YES;
}

- (void)disconnect
{
    [self goOffline];
    [xmppStream disconnect];
}

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark XMPPStream Delegate
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (void)xmppStream:(XMPPStream *)sender socketDidConnect:(GCDAsyncSocket *)socket
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
}
- (void)xmppStream:(XMPPStream *)sender willSecureWithSettings:(NSMutableDictionary *)settings
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    NSString *expectedCertName = [xmppStream.myJID domain];
    if (expectedCertName)
    {
        settings[(NSString *) kCFStreamSSLPeerName] = expectedCertName;
    }
    
    if (customCertEvaluation)
    {
        settings[GCDAsyncSocketManuallyEvaluateTrust] = @(YES);
    }
}

- (void)xmppStream:(XMPPStream *)sender didReceiveTrust:(SecTrustRef)trust
 completionHandler:(void (^)(BOOL shouldTrustPeer))completionHandler
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
        // The delegate method should likely have code similar to this,
        // but will presumably perform some extra security code stuff.
        // For example, allowing a specific self-signed certificate that is known to the app.
    
    dispatch_queue_t bgQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(bgQueue, ^{
        
        SecTrustResultType result = kSecTrustResultDeny;
        OSStatus status = SecTrustEvaluate(trust, &result);
        
        if (status == noErr && (result == kSecTrustResultProceed || result == kSecTrustResultUnspecified)) {
            completionHandler(YES);
        }
        else {
            completionHandler(NO);
        }
    });
}

- (void)xmppStreamDidSecure:(XMPPStream *)sender
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
}

- (void)xmppStreamDidConnect:(XMPPStream *)sender
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    isXmppConnected = YES;
    
    NSError *error = nil;
    
    if (![[self xmppStream] authenticateWithPassword:password error:&error])
    {
        DDLogError(@"Error authenticating: %@", error);
    }
}

- (void)xmppStreamDidAuthenticate:(XMPPStream *)sender
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    [self goOnline];
}

- (void)xmppStream:(XMPPStream *)sender didNotAuthenticate:(NSXMLElement *)error
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
}

- (BOOL)xmppStream:(XMPPStream *)sender didReceiveIQ:(XMPPIQ *)iq
{
    if([[iq attributeStringValueForName:@"id"] isEqualToString:@"chat1"])
    {
            //Extract contact list from response here
        DDXMLElement * queryElement = [iq elementForName:@"query" xmlns:@"urn:xmpp:archive"];
        
        NSArray *items = [queryElement elementsForName:@"chat"];
        
        for (DDXMLElement *i in items) {
            [[SingletonClass shareSingleton].starTime addObject:[i attributeStringValueForName:@"start"]];
        }
    }
    
    /* if([[iq attributeStringValueForName:@"id"] isEqualToString:@"recievMsg"])
     {
     //Extract contact list from response here
     DDXMLElement * queryElement = [iq elementForName:@"query" xmlns:@"urn:xmpp:archive"];
     
     NSArray *items = [queryElement elementsForName:@"chat"];
     
     for (DDXMLElement *i in items) {
     [[SingletonClass shareSingleton].starTime addObject:[i attributeStringValueForName:@"start"]];
     }
     }
     */
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    return NO;
}

- (void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message
{
        //DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
        // A simple example of inbound message handling.
    
    if ([message isChatMessageWithBody])
    {
            //NSLog(@"messages recieved %@",message);
        
        NSString * msgCnt=[[NSUserDefaults standardUserDefaults]objectForKey:@"messageCnt"];
        
        if (!msgCnt) {
            countMsg=0;
        }
        else{
            countMsg=[msgCnt intValue];
            countMsg=countMsg+1;
        }
        
        [[NSUserDefaults standardUserDefaults]setObject:[NSString stringWithFormat:@"%d",countMsg] forKey:@"messageCnt"];
        [[NSUserDefaults standardUserDefaults]synchronize];
        
        
        XMPPUserCoreDataStorageObject *user = [xmppRosterStorage userForJID:[message from]
                                                                 xmppStream:xmppStream
                                                       managedObjectContext:[self managedObjectContext_roster]];
        
        
        time_t  unixTime;
        unixTime=(time_t) [[NSDate date] timeIntervalSince1970];
        NSString * unix_time=[NSString stringWithFormat:@"%ld",unixTime];
        
        NSString *body = [[message elementForName:@"body"] stringValue];
        NSString *displayName = [user jidStr];
        
        
        if (![[self.storeNewMsg objectForKey:@"jid"]isEqualToString:displayName]) {
            [self.storeNewMsg setObject:displayName forKey:@"jid"];
            [self.storeNewMsg setObject:body forKey:@"msg"];
            
            
        }
        else{
            
            [self.storeNewMsg setObject:body forKey:@"msg"];
            
        }
        [self.unreadMsgArr addObject:self.storeNewMsg];
        NSString * name=[NSString stringWithFormat:@"%@@takadating.com",[SingletonClass shareSingleton].chattingWith];
        NSLog(@"%@",[SingletonClass shareSingleton].chattingWith);
        if ([displayName isEqualToString:name]) {
            
            NSMutableDictionary * dict=[[NSMutableDictionary alloc]init];
            [dict setObject:body forKey:@"msg"];
            [dict setObject:displayName forKey:@"sender"];
            [dict setObject:unix_time forKey:@"time"];
            
            [[SingletonClass shareSingleton].messages addObject:dict];
        }
        
        if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive)
        {
            [[NSNotificationCenter defaultCenter]postNotificationName:@"recievedMsg" object:nil userInfo:nil];
//            if(mdVC)
//            {
//                mdVC=nil;
//            }
                //   mdVC=[[MessageDetailViewController alloc]initWithNibName:@"MessageDetailViewController" bundle:nil];
                // [mdVC  showSecievedMsg ];
                // [[NSNotificationCenter defaultCenter]removeObserver:self name:@"recievedMsg" object:nil];
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:displayName
                                                                message:body
                                                               delegate:nil
                                                      cancelButtonTitle:@"Ok"
                                                      otherButtonTitles:nil];
                //[alertView show];
        }
        else
        {
                // We are not active, so use a local notification instead
            UILocalNotification *localNotification = [[UILocalNotification alloc] init];
            localNotification.alertAction = @"Ok";
            localNotification.alertBody = [NSString stringWithFormat:@"From: %@\n\n%@",displayName,body];
            
            [[UIApplication sharedApplication] presentLocalNotificationNow:localNotification];
        }
    }
}

- (void)xmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence
{
    DDLogVerbose(@"%@: %@ - %@", THIS_FILE, THIS_METHOD, [presence fromStr]);
    
    NSString *presenceType = [presence type];            // online/offline
    NSString *myUsername = [[sender myJID] user];
    NSString *presenceFromUser = [[presence from] user];
        //
        //new request from unknow user
    if (![presenceFromUser isEqualToString:myUsername])
    {
        if  ([presenceType isEqualToString:@"subscribe"])
        {
                // [_chatDelegate newBuddyOnline:[NSString stringWithFormat:@"%@@%@", presenceFromUser, kHostName]];
            XMPPPresence *tempPresence = [[XMPPPresence alloc] init];
            tempPresence = presence;
            [[self xmppStream] sendElement:presence];
            NSLog(@"presence user wants to subscribe %@",presenceFromUser);
            
                // UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"New request From:" message:presenceFromUser delegate:self cancelButtonTitle:@"NO" otherButtonTitles:@"YES", nil];
                // [alert show];
        }
    }
    
        //    if ([presenceFromUser isEqualToString:myUsername])
        //    {
        //        XMPPPresence *tempPresence = [[XMPPPresence alloc] init];
        //        tempPresence = presence;
        //        [[self xmppStream] sendElement:presence];
        //    }
}

- (void)xmppStream:(XMPPStream *)sender didReceiveError:(id)error
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
}

- (void)xmppStreamDidDisconnect:(XMPPStream *)sender withError:(NSError *)error
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    if (!isXmppConnected)
    {
        DDLogError(@"Unable to connect to server. Check xmppStream.hostName");
    }
}
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark XMPPRosterDelegate
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (void)xmppRoster:(XMPPRoster *)sender didReceiveBuddyRequest:(XMPPPresence *)presence
{
    DDLogVerbose(@"%@: %@", THIS_FILE, THIS_METHOD);
    
    XMPPUserCoreDataStorageObject *user = [xmppRosterStorage userForJID:[presence from]
                                                             xmppStream:xmppStream
                                                   managedObjectContext:[self managedObjectContext_roster]];
    
    NSString *displayName = [user displayName];
    NSString *jidStrBare = [presence fromStr];
    NSString *body = nil;
    
    if (![displayName isEqualToString:jidStrBare])
    {
        body = [NSString stringWithFormat:@"Buddy request from %@ <%@>", displayName, jidStrBare];
    }
    else
    {
        body = [NSString stringWithFormat:@"Buddy request from %@", displayName];
    }
    
    
    if ([[UIApplication sharedApplication] applicationState] == UIApplicationStateActive)
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:displayName
                                                            message:body
                                                           delegate:nil
                                                  cancelButtonTitle:@"Not implemented"
                                                  otherButtonTitles:nil];
            //[alertView show];
    }
    else
    {
            // We are not active, so use a local notification instead
        UILocalNotification *localNotification = [[UILocalNotification alloc] init];
        localNotification.alertAction = @"Not implemented";
        localNotification.alertBody = body;
        
        [[UIApplication sharedApplication] presentLocalNotificationNow:localNotification];
    }
    
}



@end
