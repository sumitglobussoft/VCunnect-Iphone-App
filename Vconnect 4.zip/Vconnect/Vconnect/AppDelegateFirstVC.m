//
//  AppDelegateFirstVC.m
//  UberValetService
//
//  Created by Globussoft 1 on 10/30/14.
//  Copyright (c) 2014 Globussoft 1. All rights reserved.
//

#import "AppDelegateFirstVC.h"
#import "ViewController.h"
#import "RegisterVC.h"

@interface AppDelegateFirstVC ()
{
    ViewController *loginVC;
    RegisterVC *registerVC;
}
@end

@implementation AppDelegateFirstVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];    
    
    UIButton *loginButton=[UIButton buttonWithType:UIButtonTypeCustom];
    [loginButton addTarget:self action:@selector(loginButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *registerButton=[UIButton buttonWithType:UIButtonTypeCustom];
    [registerButton addTarget:self action:@selector(registerButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    
    
    [loginButton setImage:[UIImage imageNamed:@"login.png"] forState:UIControlStateNormal];
    [registerButton setImage:[UIImage imageNamed:@"signup.png"] forState:UIControlStateNormal];

    if (IS_IPHONE_4_OR_LESS) {
        self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"splash_screen.png"]];
        
        loginButton.frame=CGRectMake(self.view.bounds.size.width/2-60, self.view.bounds.size.height-220, 120, 30);
        registerButton.frame=CGRectMake(self.view.bounds.size.width/2-60, self.view.bounds.size.height-160, 120, 30);
        
    }else if (IS_IPHONE_5){
        self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"splash_screen_568.png"]];
        
        loginButton.frame=CGRectMake(self.view.bounds.size.width/2-60, self.view.bounds.size.height-300, 120, 30);
        registerButton.frame=CGRectMake(self.view.bounds.size.width/2-60, self.view.bounds.size.height-240, 120, 30);
    
    }
    else if (IS_IPHONE_6){
        self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"splash_screen_750@2x.png"]];
        loginButton.frame=CGRectMake(self.view.bounds.size.width/2-55, self.view.bounds.size.height-350, 120, 30);
        registerButton.frame=CGRectMake(self.view.bounds.size.width/2-55, self.view.bounds.size.height-290, 120, 30);
    
    }
    else{
        
      self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"splash_screen@3x.png"]];
            
      loginButton.frame=CGRectMake(self.view.bounds.size.width/2-55, self.view.bounds.size.height-380, 120, 30);
       registerButton.frame=CGRectMake(self.view.bounds.size.width/2-55, self.view.bounds.size.height-300, 120, 30);
    
    }

    
    [self.view addSubview:loginButton];
    
    [self.view addSubview:registerButton];

    // Do any additional setup after loading the view.
}


-(void)registerButtonClick:(UIButton *)button{
    BOOL connect=[[NSUserDefaults standardUserDefaults]boolForKey:@"CurrentNetworkStatus"];
    
    if (!connect) {
        UIAlertView *alert =[[UIAlertView alloc] initWithTitle:@"There is no Internet Connection in your device" message:@"Check Internet Connection" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
        
    }else{
        
        if (!registerVC) {
            registerVC=[[RegisterVC alloc] init];
        }
         [self.navigationController pushViewController:registerVC animated:YES];
        
    }
}

-(void)loginButtonClick:(UIButton *)button{
    BOOL connect=[[NSUserDefaults standardUserDefaults]boolForKey:@"CurrentNetworkStatus"];
    
    if (!connect) {
        UIAlertView *alert =[[UIAlertView alloc] initWithTitle:@"There is no Internet Connection in your device" message:@"Check Internet Connection" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
        [alert show];
    }else{

    loginVC=[[ViewController alloc] init];
        [self.navigationController pushViewController:loginVC animated:YES];
    }
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
