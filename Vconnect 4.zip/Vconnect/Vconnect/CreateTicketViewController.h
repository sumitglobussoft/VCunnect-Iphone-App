//
//  CreateTicketViewController.h
//  Vconnect
//
//  Created by Globussoft 1 on 4/17/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol sendticketProtocol <NSObject>
-(void)sendTicketDetailArray:(NSArray *)taglistArray;


@end
@interface CreateTicketViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)UIButton *CreateEvent;
@property(nonatomic,strong)UIScrollView *scrollView;
@property(nonatomic,strong)NSMutableArray *tableDatalist;
@property(nonatomic)NSInteger currentSelectedInedx;
@property(nonatomic,strong)NSMutableArray *ticketTypeArr;
@property(nonatomic,strong)NSMutableArray *ticketPriceArr;
@property(nonatomic,strong)NSMutableArray *ticketQuantityArr;
@property(nonatomic,strong)NSMutableArray *ticketDetailArr;
@property(nonatomic,assign)id ticketDelegate;
@end
