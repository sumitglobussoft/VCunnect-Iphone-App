//
//  MapViewController.h
//  Vconnect
//
//  Created by Globussoft 1 on 6/10/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <QuartzCore/QuartzCore.h>

@interface MapViewController : UIViewController<MKAnnotation,MKMapViewDelegate,MKOverlay>
{
    CALayer *waveLayer;
    BOOL inAnimation;
}

@property(nonatomic,strong)MKMapView *mapUser;

@end
