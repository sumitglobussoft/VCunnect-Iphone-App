//
//  ProfileViewController.m
//  Vconnect
//
//  Created by Sumit on 12/03/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import "ProfileViewController.h"
#import "LocationSearchVIewController.h"
#import "EditProfileViewController.h"

@interface ProfileViewController ()

@end

@implementation ProfileViewController
@synthesize topview,firstview,secondview,thirdview,nameText,email,website,phono,hometown,fourthview,location,memberLabel,firstNameLabel,lastNameLabel,PhoneLabel,countryLabel,stateLabel,cityLabel,homePhoneLabel,workPhoneLabel,cellPhoneLabel;

- (void)viewDidLoad {
   
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithRed:(CGFloat)225/255 green:(CGFloat)225/255 blue:(CGFloat)225/255 alpha:1];
    topview=[[UIView alloc]init];
    topview.backgroundColor=[UIColor colorWithRed:(CGFloat)245/255 green:(CGFloat)245/255 blue:(CGFloat)245/255 alpha:1];
    topview.layer.cornerRadius = 5;
    topview.layer.masksToBounds = YES;
    [self.view addSubview:topview];
    topview.layer.shadowColor = [UIColor blackColor].CGColor;
    topview.layer.shadowOpacity = 0.4f;
    topview.layer.shadowOffset = CGSizeMake(0.0f, 4.0f);
    topview.layer.shadowRadius = 1.5f;
    topview.layer.masksToBounds = NO;
    
    UILabel *FullNameLabel = [[UILabel alloc]init];
    FullNameLabel.frame = CGRectMake(150, 30, 100, 150);
    FullNameLabel.text = @"Vinayaka S Yattinahalli";
    FullNameLabel.lineBreakMode = NSLineBreakByWordWrapping;
    FullNameLabel.numberOfLines = 0;
    [ FullNameLabel setFont:[UIFont fontWithName:@"Arial-BoldMT" size:18]];
    [topview addSubview:FullNameLabel];
    
    
    firstview=[[UIView alloc]init];
    firstview.frame=CGRectMake(10, 170, self.view.frame.size.width-20, self.view.frame.size.height-170);
       firstview.layer.cornerRadius = 5;
    firstview.layer.masksToBounds = YES;
    firstview.backgroundColor= [UIColor colorWithRed:(CGFloat)245/255 green:(CGFloat)245/255 blue:(CGFloat)245/255 alpha:1];
    [self.view addSubview:firstview];
    firstview.layer.shadowColor = [UIColor blackColor].CGColor;
    firstview.layer.shadowOpacity = 0.2f;
    firstview.layer.shadowOffset = CGSizeMake(0.0f, -2.0f);
    firstview.layer.shadowRadius = 2.0f;
    firstview.layer.masksToBounds = NO;

    self.scrollView=[[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, firstview.bounds.size.width, firstview.bounds.size.height)];
    self.scrollView.delegate=self;
    self.scrollView.backgroundColor=[UIColor clearColor];
    [self.scrollView setContentSize:CGSizeMake(firstview.bounds.size.width, self.scrollView.frame.size.height+200)];
    [firstview addSubview:self.scrollView];
    
    self.memberLabel = [[UILabel alloc]init];
    self.memberLabel.frame = CGRectMake(30, 0, 250, 40);
    self.memberLabel.text = @"Vcunnect member since 1 year";
    self.memberLabel.textColor=[UIColor colorWithRed:17.0/255.0 green:147.0/255.0 blue:132.0/255.0 alpha:1.0];
    [self.memberLabel setFont:[UIFont fontWithName:@"Arial-BoldMT" size:20]];
    self.memberLabel.lineBreakMode=NSLineBreakByWordWrapping;
    self.memberLabel.numberOfLines=0;
    [self.scrollView addSubview:self.memberLabel];
    [self.memberLabel sizeToFit];
    
    
    UIButton *editProfileButton = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [editProfileButton addTarget:self
                          action:@selector(aMethod:)
                forControlEvents:UIControlEventTouchUpInside];
        //    editProfileButton.backgroundColor = [UIColor redColor];
    [editProfileButton setImage:[UIImage imageNamed:@"edit.png"]  forState:UIControlStateNormal];
    editProfileButton.frame = CGRectMake(firstview.frame.size.width-30, 10.0, 100.0, 40.0);
    [self.scrollView addSubview:editProfileButton];

    
    
    self.firstNameLabel = [[UILabel alloc]init];
    self.firstNameLabel.frame = CGRectMake(10, 30, 250, 30);
    self.firstNameLabel.text = @"First Name";
    [self.firstNameLabel setFont:[UIFont fontWithName:@"Arial-BoldMT" size:18]];
    [self.scrollView addSubview:self.firstNameLabel];

    
    UILabel *nameLabel = [[UILabel alloc]init];
    nameLabel.frame = CGRectMake(10, 70, 250, 20);
    nameLabel.text = @"Vinayaka";
   // nameLabel.font=[UIFont systemFontOfSize:25.0f];
    [self.scrollView addSubview:nameLabel];

    UIView * separator = [[UIView alloc] initWithFrame:CGRectMake(0, 95, self.view.frame.size.width-60, 1)];
    separator.backgroundColor = [UIColor colorWithWhite:0.7 alpha:1];
    [self.scrollView addSubview:separator];
    
    self.lastNameLabel = [[UILabel alloc]init];
    self.lastNameLabel.frame = CGRectMake(10, 100, 250, 30);
    self.lastNameLabel.text = @"Last Name";
    [ self.lastNameLabel setFont:[UIFont fontWithName:@"Arial-BoldMT" size:18]];
    [self.scrollView addSubview:self.lastNameLabel];
    
    UILabel *lastName =[[UILabel alloc]init];
    lastName.frame = CGRectMake(10, 135, 250, 20);
    lastName.text = @"Yattinahalli";
    // nameLabel.font=[UIFont systemFontOfSize:25.0f];
    [self.scrollView addSubview:lastName];
    
    UIView * separator1= [[UIView alloc] initWithFrame:CGRectMake(0, 160, self.view.frame.size.width-60, 1)];
    separator1.backgroundColor = [UIColor colorWithWhite:0.7 alpha:1];
    [self.scrollView addSubview:separator1];

    self.homePhoneLabel = [[UILabel alloc]init];
    self.homePhoneLabel.frame = CGRectMake(10, 162, 250, 30);
    self.homePhoneLabel.text = @"Home Phone";
     [ self.homePhoneLabel setFont:[UIFont fontWithName:@"Arial-BoldMT" size:18]];
    [self.scrollView addSubview:self.homePhoneLabel];
    
    UILabel *homePhone =[[UILabel alloc]init];
    homePhone.frame = CGRectMake(10, 195, 250, 20);
    homePhone.text = @"080-51458585";
    // nameLabel.font=[UIFont systemFontOfSize:25.0f];
    [self.scrollView addSubview:homePhone];
    
    UIView * separator2= [[UIView alloc] initWithFrame:CGRectMake(0, 220, self.view.frame.size.width-60, 1)];
    separator2.backgroundColor = [UIColor colorWithWhite:0.7 alpha:1];
    [self.scrollView addSubview:separator2];
    
    self.workPhoneLabel = [[UILabel alloc]init];
    self.workPhoneLabel.frame = CGRectMake(10, 220, 250, 30);
    self.workPhoneLabel.text = @"Work Phone";
   [ self.workPhoneLabel setFont:[UIFont fontWithName:@"Arial-BoldMT" size:18]];
    [self.scrollView  addSubview:self.workPhoneLabel];
    
    UILabel *workPhone =[[UILabel alloc]init];
    workPhone.frame = CGRectMake(10, 252, 250, 20);
    workPhone.text = @"080-5145858578";
    // nameLabel.font=[UIFont systemFontOfSize:25.0f];
    [self.scrollView addSubview:workPhone];

    UIView * separator3= [[UIView alloc] initWithFrame:CGRectMake(0, 277, self.view.frame.size.width-60, 1)];
    separator3.backgroundColor = [UIColor colorWithWhite:0.7 alpha:1];
    [self.scrollView addSubview:separator3];

    
    self.cellPhoneLabel = [[UILabel alloc]init];
    self.cellPhoneLabel.frame = CGRectMake(10, 278, 250, 30);
    self.cellPhoneLabel.text = @"Cell Phone";
    [self.cellPhoneLabel setFont:[UIFont fontWithName:@"Arial-BoldMT" size:18]];
    [self.scrollView addSubview:self.cellPhoneLabel];
    
    UILabel *cellPhone =[[UILabel alloc]init];
    cellPhone.frame = CGRectMake(10, 310, 250, 20);
    cellPhone.text = @"9713358770";
    // nameLabel.font=[UIFont systemFontOfSize:25.0f];
   [self.scrollView addSubview:cellPhone];
    
    UIView * separator4= [[UIView alloc] initWithFrame:CGRectMake(0, 220, self.view.frame.size.width-60, 1)];
    separator4.backgroundColor = [UIColor colorWithWhite:0.7 alpha:1];
     [self.scrollView addSubview:separator4];

    UIView * separator5= [[UIView alloc] initWithFrame:CGRectMake(0, 333, self.view.frame.size.width-60, 1)];
    separator5.backgroundColor = [UIColor colorWithWhite:0.7 alpha:1];
    [self.scrollView addSubview:separator5];
    
    self.cityLabel = [[UILabel alloc]init];
    self.cityLabel.frame = CGRectMake(10, 333, 250, 30);
    self.cityLabel.text = @"Current City";
    [ self.cityLabel setFont:[UIFont fontWithName:@"Arial-BoldMT" size:18]];
    [self.scrollView addSubview:self.cityLabel];
    
    UILabel *cityNameLabel =[[UILabel alloc]init];
    cityNameLabel.frame = CGRectMake(10, 370, 250, 20);
    cityNameLabel.text = @"Bhilai";
        // nameLabel.font=[UIFont systemFontOfSize:25.0f];
    [self.scrollView addSubview:cityNameLabel];
    
    UIView * separator6= [[UIView alloc] initWithFrame:CGRectMake(0, 393, self.view.frame.size.width-60, 1)];
    separator6.backgroundColor = [UIColor colorWithWhite:0.7 alpha:1];
    [self.scrollView addSubview:separator6];
    
    self.stateLabel = [[UILabel alloc]init];
    self.stateLabel.frame = CGRectMake(10, 390, 250, 30);
    self.stateLabel.text = @"State";
    [ self.stateLabel setFont:[UIFont fontWithName:@"Arial-BoldMT" size:18]];
    [self.scrollView  addSubview:self.stateLabel];
    
    UILabel *stateName =[[UILabel alloc]init];
    stateName.frame = CGRectMake(10, 430, 250, 20);
    stateName.text = @"Chhattishgarh";
        // nameLabel.font=[UIFont systemFontOfSize:25.0f];
    [self.scrollView addSubview:stateName];

    UIView * separator7= [[UIView alloc] initWithFrame:CGRectMake(0, 453, self.view.frame.size.width-60, 1)];
    separator7.backgroundColor = [UIColor colorWithWhite:0.7 alpha:1];
    [self.scrollView addSubview:separator7];
    
    self.countryLabel = [[UILabel alloc]init];
    self.countryLabel.frame = CGRectMake(10, 454, 250, 30);
    self.countryLabel.text = @"Country";
    [ self.countryLabel setFont:[UIFont fontWithName:@"Arial-BoldMT" size:18]];
    [self.scrollView  addSubview:self.countryLabel];
    
    UILabel *countryName =[[UILabel alloc]init];
    countryName.frame = CGRectMake(10, 489, 250, 20);
    countryName.text = @"India";
        // nameLabel.font=[UIFont systemFontOfSize:25.0f];
    [self.scrollView addSubview:countryName];
    

    self.imageView = [[RoundedImageView alloc] init ];
    self.imageView.frame=CGRectMake(10, 30, 100, 100);
    self.imageView.image=[UIImage imageNamed:@"profile.png"];
    [self.imageView setUserInteractionEnabled:YES];
    UITapGestureRecognizer *gesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageGestureRecognizer:)];
    [self.imageView addGestureRecognizer:gesture];
    [self.topview addSubview:self.imageView];
    
    if (IS_IPHONE_4_OR_LESS) {
        FullNameLabel.frame = CGRectMake(150, 30, 100, 100);
        self.memberLabel.frame = CGRectMake(20, 0, 250, 40);
        editProfileButton.frame = CGRectMake(180.0, 0.0, 100.0, 40.0);
        self.firstNameLabel.frame = CGRectMake(10, 30, 250, 30);
        nameLabel.frame = CGRectMake(10, 70, 250, 20);
        self.lastNameLabel.frame = CGRectMake(10, 100, 250, 30);
        lastName.frame = CGRectMake(10, 135, 250, 20);
        self.homePhoneLabel.frame = CGRectMake(10, 162, 250, 30);
        homePhone.frame = CGRectMake(10, 195, 250, 20);
        self.workPhoneLabel.frame = CGRectMake(10, 220, 250, 30);
        workPhone.frame = CGRectMake(10, 252, 250, 20);
       
        topview.frame = CGRectMake(10, 0, self.view.frame.size.width-20, 150);
        
        separator.frame = CGRectMake(0, 95, self.view.frame.size.width-60, 1);
        separator1.frame=CGRectMake(0, 160, self.view.frame.size.width-60, 1);
        separator2.frame=CGRectMake(0, 220, self.view.frame.size.width-60, 1);
    }else if (IS_IPHONE_5){
        
        topview.frame = CGRectMake(10, 0, self.view.frame.size.width-20, 180);
        firstview.frame = CGRectMake(10, 220, self.view.frame.size.width-20, self.view.frame.size.height-160) ;

        separator.frame = CGRectMake(0, 100, self.view.frame.size.width-60, 1);
        separator1.frame=CGRectMake(0, 165, self.view.frame.size.width-60, 1);
        separator2.frame=CGRectMake(0, 230, self.view.frame.size.width-60, 1);
        
        self.memberLabel.frame = CGRectMake(20, 0, 250, 40);
        editProfileButton.frame = CGRectMake(180.0, 0.0, 100.0, 40.0);
        
        FullNameLabel.frame = CGRectMake(150, 40, 100, 100);
        self.firstNameLabel.frame = CGRectMake(10, 50, 250, 30);
        nameLabel.frame = CGRectMake(10, 80, 250, 20);
        self.lastNameLabel.frame = CGRectMake(10, 110, 250, 30);
        lastName.frame = CGRectMake(10, 145, 250, 20);
        self.homePhoneLabel.frame = CGRectMake(10, 173, 250, 30);
        homePhone.frame = CGRectMake(10, 210, 250, 20);
        self.workPhoneLabel.frame = CGRectMake(10, 240, 250, 30);
        workPhone.frame = CGRectMake(10, 280, 250, 20);
    }else if (IS_IPHONE_6){
        FullNameLabel.frame = CGRectMake(150, 30, 100, 100);
        self.memberLabel.frame = CGRectMake(20, 0, 250, 40);
                self.firstNameLabel.frame = CGRectMake(10, 30, 250, 30);
        nameLabel.frame = CGRectMake(10, 70, 250, 20);
        self.lastNameLabel.frame = CGRectMake(10, 100, 250, 30);
        lastName.frame = CGRectMake(10, 135, 250, 20);
        self.homePhoneLabel.frame = CGRectMake(10, 162, 250, 30);
        homePhone.frame = CGRectMake(10, 195, 250, 20);
        self.workPhoneLabel.frame = CGRectMake(10, 220, 250, 30);
        workPhone.frame = CGRectMake(10, 252, 250, 20);
          firstview.frame = CGRectMake(10, 170, self.view.frame.size.width-20, self.view.frame.size.height-200) ;
        self.scorlView.frame=CGRectMake(0, 0, firstview.frame.size.width, firstview.frame.size.height) ;
        editProfileButton.frame = CGRectMake(firstview.frame.size.width-80, 0.0, 100.0, 40.0);

        topview.frame = CGRectMake(10, 0, self.view.frame.size.width-20, 150);
        firstview.frame = CGRectMake(10, 170, self.view.frame.size.width-20, self.view.frame.size.height-200) ;
    }else{
        FullNameLabel.frame = CGRectMake(150, 30, 100, 100);
        self.memberLabel.frame = CGRectMake(20, 0, 250, 40);
        editProfileButton.frame = CGRectMake(180.0, 0.0, 100.0, 40.0);
        self.firstNameLabel.frame = CGRectMake(10, 30, 250, 30);
        nameLabel.frame = CGRectMake(10, 70, 250, 20);
        self.lastNameLabel.frame = CGRectMake(10, 100, 250, 30);
        lastName.frame = CGRectMake(10, 135, 250, 20);
        self.homePhoneLabel.frame = CGRectMake(10, 162, 250, 30);
        homePhone.frame = CGRectMake(10, 195, 250, 20);
        self.workPhoneLabel.frame = CGRectMake(10, 220, 250, 30);
        workPhone.frame = CGRectMake(10, 252, 250, 20);
        
        topview.frame = CGRectMake(10, 0, self.view.frame.size.width-20, 150);
        firstview.frame = CGRectMake(10, 170, self.view.frame.size.width-20, self.view.frame.size.height-200) ;
    }

   
    // Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBarHidden = YES;
}
-(void)aMethod:(id)sender{
    NSLog(@"edit profile method called");

    EditProfileViewController *edit=[[EditProfileViewController alloc]init];
   
    [self.navigationController pushViewController:edit animated:YES];
    
  //  [self.navigationController addChildViewController:edit];
 //   [self.view addSubview:edit.view];
    
}

//The event handling method
- (void)handleSingleTap:(UITapGestureRecognizer *)recognizer {
    CGPoint location1 = [recognizer locationInView:[recognizer.view superview]];
    NSLog(@"location is %f, %f",location1.x,location1.y );
    
    LocationSearchVIewController *loc = [[LocationSearchVIewController alloc]init];
    [self presentViewController:loc animated:YES completion:nil];
    //Do stuff here...
}


-(void)createEventWebservice{
    
    

}


-(void)imageGestureRecognizer:(UIGestureRecognizer *)gesture{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    [imagePicker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    [imagePicker setDelegate:self];
    [self addChildViewController:imagePicker];
    [self.view addSubview:imagePicker.view];
    //    [self  presentViewController:imagePicker animated:YES completion:nil];
    
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    [picker.view removeFromSuperview];
    //    [picker dismissViewControllerAnimated:YES completion:nil];
    self.imageView.image = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
}


- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}


@end
