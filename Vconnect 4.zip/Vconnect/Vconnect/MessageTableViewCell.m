//
//  MessageTableViewCell.m
//  TakaDating
//
//  Created by Sumit Ghosh on 30/11/14.
//  Copyright (c) 2014 Sumit Ghosh. All rights reserved.
//

#import "MessageTableViewCell.h"

@implementation MessageTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
        self.containerView=[[UIView alloc]init];
        self.containerView.backgroundColor=[UIColor clearColor];
        [self.contentView addSubview:self.containerView];
        
        
        self.cellLabel=[[UILabel alloc]init];
        self.cellLabel.font=[UIFont boldSystemFontOfSize:12];
        self.cellLabel.textColor=[UIColor blackColor];
        [self.containerView addSubview:self.cellLabel];
        
        self.cellDetailLbel=[[UILabel alloc]init];
        self.cellDetailLbel.font=[UIFont systemFontOfSize:12];
        self.cellDetailLbel.textColor=[UIColor blackColor];
        self.cellDetailLbel.numberOfLines=0;
        self.cellDetailLbel.lineBreakMode=NSLineBreakByWordWrapping;
        [self.containerView addSubview:self.cellDetailLbel];
        
        self.deleteButton=[UIButton buttonWithType:UIButtonTypeCustom];
        [self.deleteButton setImage:[UIImage imageNamed:@"select_normal.png"] forState:UIControlStateNormal];
        [self.deleteButton setImage:[UIImage imageNamed:@"select_active.png"] forState:UIControlStateSelected];
        [self.containerView addSubview: self.deleteButton];
        
        self.imgView=[[UIImageView alloc]init];
       //self.imgView.layer.cornerRadius=self.imageView.frame.size.width/2;
        self.imgView.clipsToBounds=YES;
        [self.containerView addSubview:self.imgView];
        
    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
