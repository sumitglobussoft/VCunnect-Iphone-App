//
//  TableViewCell.h
//  NextInsure
//
//  Created by Sumit on 06/02/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCell : UITableViewCell<UITextFieldDelegate,UITextViewDelegate>
@property(nonatomic,strong)UILabel *title;
@property(nonatomic,strong)UILabel *forShowingTime ;
@property(nonatomic,strong)UILabel *label3 ;
@property(nonatomic,strong)UILabel *headerLabel;

@property(nonatomic,strong)UIView *organizationDetail;
@property(nonatomic,strong)UILabel *orgnNameLbl;
@property(nonatomic,strong)UILabel *orgnEmailLbl;
@property(nonatomic,strong)UILabel *orgnDiscriptionLbl;

@property(nonatomic,strong)UITextField *orgnNameTxtFld;
@property(nonatomic,strong)UITextField *orgnEmailTxtFld;
@property(nonatomic,strong)UITextView *orgnDiscriptionTxtFld;
@end
