//
//  GameState.h
//  DartWheel
//
//  Created by Sumit Ghosh on 31/05/14.
//
//

#import <Foundation/Foundation.h>


@interface SingletonClass : NSObject

@property (nonatomic, assign) NSIndexPath* selectedUserIndex;

@property (nonatomic,assign) BOOL isGamePlaying ;
@property (nonatomic, retain)NSMutableArray *messages;
@property (nonatomic,assign)NSString *userID;
@property (nonatomic,assign)NSMutableArray *starTime;
@property (nonatomic,assign)NSString *chattingWith;
@property (nonatomic,assign)NSMutableArray *sortedData;
@property (nonatomic,assign) BOOL fromChat;
+(SingletonClass*)shareSingleton;
@end
