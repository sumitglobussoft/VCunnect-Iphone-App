//
//  CreateGroupViewController.h
//  Vconnect
//
//  Created by Globussoft 1 on 4/16/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CreateTicketViewController.h"
#import "MapViewController.h"
#import "AddMoreOrganizer.h"

@interface CreateGroupViewController : UIViewController<UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIScrollViewDelegate,UITextViewDelegate,sendticketProtocol>{
    UIToolbar *toolBar;

}
@property(nonatomic,strong)AddMoreOrganizer *addmoreOrgnizer;
@property(nonatomic,strong)NSString *startTimeStr;
@property(nonatomic,strong)NSString *endTimeStr;
@property(nonatomic,strong)NSString *startDateStr;
@property(nonatomic,strong)NSString *endDateStr;
@property(nonatomic,strong)UIView * texturedBackgroundView;
@property(nonatomic,strong)MapViewController *mapViewController;
@property(nonatomic,strong)UIImageView * profileImageView;
@property(nonatomic,strong)  UIDatePicker *datePicker;
//@property(nonatomic,strong)  UIDatePicker *endDatePicker;
@property(nonatomic,strong)UIButton *eventImgUploadBtn;
@property(nonatomic,strong)UIButton *createTicketForEvent;
@property(nonatomic,strong)UIButton *showMapViewButton;

@property(nonatomic,strong)UITextField *eventTitleField;
@property(nonatomic,strong)UIScrollView *scrollView;
@property (nonatomic,strong)UITextField *locationTxtField;
@property(nonatomic,strong)UITextField *vanueField;
@property (nonatomic,strong)UITextField *addressTxtField;
@property(nonatomic,strong)UITextField *ageTxtField;
@property(nonatomic,strong)UITextField *startDateField;
@property(nonatomic,strong)UITextField *endDateField;
@property(nonatomic,strong)UILabel *eventTitleLabel;

@property(nonatomic,strong)UILabel *locationLabel;

@property(nonatomic,strong)UILabel *eventDescription;
@property(nonatomic,strong)UITextView *eventDescriptionTextView;

@property(nonatomic,strong)UILabel *startDate;
@property(nonatomic,strong)UILabel *endDate;
@property(nonatomic,strong)UILabel *vanueLabel;

@property(nonatomic,strong)UILabel *cityLbl;
@property(nonatomic,strong)UILabel *StateLbl;
@property(nonatomic,strong)UILabel *countryLbl;

@property(nonatomic,strong)UIView *addressDetailView;
@property(nonatomic,strong)UILabel *address1Lbl;
@property(nonatomic,strong)UILabel *address2Lbl;
@property(nonatomic,strong)UITextField *cityField;
@property(nonatomic,strong)UITextField *StateField;
@property(nonatomic,strong)UITextField *countryField;
@property(nonatomic,strong)UITextField *address1Field;
@property(nonatomic,strong)UITextField *address2Field;
@property(nonatomic,strong)CreateTicketViewController *createTicketView;
@property(nonatomic,strong)UILabel *addressLabel;

@property(nonatomic,strong)UIView *organizationDetail;
@property(nonatomic,strong)UILabel *orgnNameLbl;
@property(nonatomic,strong)UILabel *orgnEmailLbl;
@property(nonatomic,strong)UILabel *orgnDiscriptionLbl;

@property(nonatomic,strong)UILabel *orgnDeclareLabel;
@property(nonatomic,strong)UIButton *orgnAddBtn;


@property(nonatomic,strong)UITextField *orgnNameTxtFld;
@property(nonatomic,strong)UITextField *orgnEmailTxtFld;
@property(nonatomic,strong)UITextView *orgnDiscriptionTxtFld;

@property(nonatomic,strong)NSDate *endDateValue;
@property(nonatomic,strong)NSDate *startDateValue;
@end
