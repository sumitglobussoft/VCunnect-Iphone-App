//
//  AddMoreOrganizer.h
//  Vconnect
//
//  Created by Globussoft 1 on 6/12/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol senddataProtocol <NSObject>
-(void)sendOrganizerDetailArray:(NSArray *)taglistArray;

@end
@interface AddMoreOrganizer : UIViewController<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UITextViewDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)UIButton *CreateEvent;
@property(nonatomic,strong)NSMutableArray *nameArray;
@property(nonatomic,strong)NSMutableArray *emailArray;
@property(nonatomic,strong)NSMutableArray *descriptionArray;
@property(nonatomic,strong)NSMutableArray *orgnDetailArray;
@property(nonatomic,strong)NSMutableArray *tableDatalist;
@property(nonatomic)NSInteger currentSelectedIndex;
@property(nonatomic,assign)id delegate;

@end
