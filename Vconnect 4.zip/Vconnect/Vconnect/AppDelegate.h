//
//  AppDelegate.h
//  Vconnect
//
//  Created by Sumit on 09/01/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//
#define API_URL  @"http://uber.globusapps.com/ws/"

#import <UIKit/UIKit.h>
#import "AppDelegateFirstVC.h"
#import "HomeVC.h"
#import "FirstVC.h"
#import "GroupViewController.h"
#import "CalendarViewController.h"
#import "MessagesViewController.h"
#import "RefreshViewController.h"
#import "InterestViewController.h"
#import "SettingsViewController.h"
#import "MBProgressHUD.h"
#import "ProfileViewController.h"


#import <CoreData/CoreData.h>
#import "XMPPFramework.h"

#import "GCDAsyncSocket.h"
#import "XMPP.h"
#import "XMPPLogging.h"
#import "XMPPReconnect.h"
#import "XMPPCapabilitiesCoreDataStorage.h"
#import "XMPPRosterCoreDataStorage.h"
#import "XMPPvCardAvatarModule.h"
#import "XMPPvCardCoreDataStorage.h"
extern NSString *const kXMPPmyJID;
extern NSString *const kXMPPmyPassword;
@class AppDelegateFirstVC;

@interface AppDelegate : UIResponder <UIApplicationDelegate,UINavigationControllerDelegate,XMPPStreamDelegate>{
     MBProgressHUD *HUD;
    XMPPStream *xmppStream;
    XMPPReconnect *xmppReconnect;
    XMPPRoster *xmppRoster;
    XMPPRosterCoreDataStorage *xmppRosterStorage;
    XMPPvCardCoreDataStorage *xmppvCardStorage;
    XMPPvCardTempModule *xmppvCardTempModule;
    XMPPvCardAvatarModule *xmppvCardAvatarModule;
    XMPPCapabilities *xmppCapabilities;
    XMPPCapabilitiesCoreDataStorage *xmppCapabilitiesStorage;
    
    NSString *password;
    BOOL customCertEvaluation;
    
    BOOL isXmppConnected;
    int countMsg;

}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) AppDelegateFirstVC *viewController ;

@property (nonatomic, strong, readonly) XMPPStream *xmppStream;
@property (nonatomic, strong, readonly) XMPPReconnect *xmppReconnect;
@property (nonatomic, strong, readonly) XMPPRoster *xmppRoster;
@property (nonatomic, strong, readonly) XMPPRosterCoreDataStorage *xmppRosterStorage;
@property (nonatomic, strong, readonly) XMPPvCardTempModule *xmppvCardTempModule;
@property (nonatomic, strong, readonly) XMPPvCardAvatarModule *xmppvCardAvatarModule;
@property (nonatomic, strong, readonly) XMPPCapabilities *xmppCapabilities;
@property (nonatomic, strong, readonly) XMPPCapabilitiesCoreDataStorage *xmppCapabilitiesStorage;

@property(nonatomic,strong)NSMutableDictionary * storeNewMsg;
@property(nonatomic,strong)NSMutableArray * unreadMsgArr;

- (NSManagedObjectContext *)managedObjectContext_roster;
- (NSManagedObjectContext *)managedObjectContext_capabilities;

- (BOOL)connect;
- (void)disconnect;
+(AppDelegate *)sharedAppDelegate;
@property(nonatomic,strong)UINavigationController *navigationController;
-(void) showHUDLoadingView:(NSString *)strTitle;
-(void) hideHUDLoadingView;
-(void)showToastMessage:(NSString *)message;

@end

