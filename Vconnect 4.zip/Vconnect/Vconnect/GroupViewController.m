//
//  GroupViewController.m
//  Vconnect
//
//  Created by Sumit on 09/02/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import "GroupViewController.h"
#import "AFTableViewCell.h"
#import "ImageViewCustomCell.h"
#import "GameState.h"

@interface GroupViewController ()

@end

@implementation GroupViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithRed:250.0f/255.0f green:250.0f/255.0f blue:250.0/255.0f alpha:0.8f];
    
    self.colorArray=[NSArray arrayWithObjects:@"redColor",@"greenColor",@"blueColor",@"brownColor",@"GrayColor",@"blackColor",@"YellowColor",@"whiteColor",@"OrangeColor",@"hello",@"hi",@"who",@"what",@"when",@"whom",@"why",@"how",@"vinayaka",@"sukhmeet",@"vv",@"gdhdff",nil];
    
//    self.colorArray=[NSArray arrayWithObjects:[UIColor redColor],[UIColor greenColor],[UIColor blueColor],[UIColor brownColor],[UIColor grayColor],[UIColor blackColor],[UIColor yellowColor],[UIColor whiteColor],[UIColor orangeColor], nil];
    
    self.searchBar=[[UISearchBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 50)];
    self.searchBar.placeholder=@"Search Groups";
    self.searchBar.delegate=self;
    [self.view addSubview:self.searchBar];

    UITableView *tableView=[[UITableView alloc] initWithFrame:CGRectMake(0,55,self.view.frame.size.width , self.view.frame.size.height-100)];
    tableView.delegate=self;
    tableView.dataSource=self;
    [self.view addSubview:tableView];
    
    
    // Do any additional setup after loading the view.
}

-(void)btn2Clicked{
    NSError * error=nil;
    NSURLResponse * urlReponse=nil;

    
    NSString *userId = [[NSUserDefaults standardUserDefaults]objectForKey:@"userId"];
    
    NSString * urlStr=[NSString stringWithFormat:@"http://api.vconnect.globusapps.com/index.php?method=profileData&UserId=%@",userId];
    
    urlStr=[urlStr stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSURL * url=[NSURL URLWithString:urlStr];
    
    NSMutableURLRequest * request=[[NSMutableURLRequest alloc]initWithURL:url cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:50];
    
    
    NSData * data=[ NSURLConnection sendSynchronousRequest:request returningResponse:&urlReponse error:&error];
    
    
    if (data==nil) {
        NSLog(@" no data");
        return;
    }
    id response=[NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&error];
    NSLog(@"reponse is %@",response);
    
    //     AppDelegate *appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
//    NSString *responseShow = [response objectForKey:@"message"];
    
//    [GameState sharedState].userId = [response objectForKey:@"UserId"];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - TableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
    
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;

}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section==0) {
        return [NSString stringWithFormat:@"Your joined groups "];
    }else{
    return [NSString stringWithFormat:@"Suggested Meetup Group"];
    }
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
   static NSString *CellIdentifier = @"CellIdentifier";
    
    if (indexPath.section==0) {
        CellIdentifier = @"CellIdentifier1";
       }else{
        CellIdentifier = @"CellIdentifier2";
       }
    AFTableViewCell *cell=(AFTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        cell=[[AFTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    return cell;

    
}

-(void)tableView:(UITableView *)tableView willDisplayCell:(AFTableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setCollectionViewDataSourceDelegate:self indexPath:indexPath];
    NSInteger index = cell.collectionView.tag;
    
//    CGFloat horizontalOffset = [self.contentOffsetDictionary[[@(index) stringValue]] floatValue];
//    [cell.collectionView setContentOffset:CGPointMake(100.0, 0)];
}

#pragma mark - UICollectionViewDataSource Methods

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
//    NSArray *collectionViewArray = self.colorArray[[(AFIndexedCollectionView *)collectionView indexPath].row];
    return self.colorArray.count;
    
//     return 10;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ImageViewCustomCell *cell = (ImageViewCustomCell *)[collectionView dequeueReusableCellWithReuseIdentifier:CollectionViewCellIdentifier forIndexPath:indexPath];
    
//   NSArray *collectionViewArray = self.colorArray[[(AFIndexedCollectionView *)collectionView indexPath].row];
//   cell.backgroundColor = collectionViewArray[indexPath.item];
   cell.backgroundColor =[UIColor colorWithRed:245.0f/255.0f green:245.0f/255.0f  blue:245.0f/255.0f  alpha:0.8];
    cell.layer.shadowColor = [UIColor blackColor].CGColor;
    cell.layer.shadowOpacity = 0.4f;
    cell.layer.shadowOffset = CGSizeMake(0.0f, 4.0f);
    cell.layer.shadowRadius = 1.5f;
    cell.layer.masksToBounds = NO;
    if (collectionView.tag==2) {
        cell.layer.cornerRadius=10.0;
    }
    return cell;
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)aSearchBar {
    [aSearchBar resignFirstResponder];
}

-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [searchBar resignFirstResponder];
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
NSLog(@"tag %ld index %ld",(long)collectionView.tag,(long)indexPath.row);
};

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
        if (IS_IPHONE_6){
            if (self.colorArray.count%2==0) {
                return 200*self.colorArray.count/2;
            }else{
                return 200*(self.colorArray.count/2+1);
            }

            
        }else if(IS_IPHONE_6P){
            if (self.colorArray.count%2==0) {
                return 200*self.colorArray.count/2;
            }else{
                return 200*(self.colorArray.count/2+1);
            }

        }
        else{
            
            if (self.colorArray.count%2==0) {
                return 165*self.colorArray.count/2;
            }else{
                return 165*(self.colorArray.count/2+1);
            }

        }

    }else{
        return 190*self.colorArray.count;
    
    }
    //    return 55*self.colorArray;

}
#pragma mark - UIScrollViewDelegate Methods

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (![scrollView isKindOfClass:[UICollectionView class]]) return;
    
    CGFloat horizontalOffset = scrollView.contentOffset.x;
    
    UICollectionView *collectionView = (UICollectionView *)scrollView;
    NSInteger index = collectionView.tag;
//    self.contentOffsetDictionary[[@(index) stringValue]] = @(horizontalOffset);
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
