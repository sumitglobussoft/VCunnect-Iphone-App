//
//  customCell.m
//  MoveytProject
//
//  Created by Globussoft 1 on 4/29/14.
//  Copyright (c) 2014 Globussoft 1. All rights reserved.
//

#import "customCell.h"


@implementation customCell


@synthesize priceLabel;


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
//       self.typeOfTicket
//        self.ShowQuantity
//        self.liveNowlabel
        
        self.typeOfTicket=[[UITextField alloc] init];
        self.typeOfTicket.font = [UIFont systemFontOfSize:15];
       self.typeOfTicket.frame=CGRectMake(0, 2,110, 40);
        self.typeOfTicket.autocorrectionType = UITextAutocorrectionTypeNo;
        self.typeOfTicket.keyboardType = UIKeyboardTypeDefault;
        self.typeOfTicket.returnKeyType = UIReturnKeyDone;
        self.typeOfTicket.clearButtonMode = UITextFieldViewModeWhileEditing;
        self.typeOfTicket.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        self.typeOfTicket.layer.cornerRadius = 1.0f;
        self.typeOfTicket.layer.masksToBounds = YES;
//        self.typeOfTicket.exclusiveTouch=YES;
        self.typeOfTicket.layer.borderColor = [[UIColor grayColor]CGColor];
        self.typeOfTicket.textAlignment = NSTextAlignmentCenter;
        self.typeOfTicket.layer.borderWidth = 2.0f;
        self.typeOfTicket.contentHorizontalAlignment=UIControlContentHorizontalAlignmentCenter;
        self.typeOfTicket.delegate = self;
        [self addSubview:self.typeOfTicket];

        self.ShowQuantity=[[UITextField alloc] init];
        self.ShowQuantity.font = [UIFont systemFontOfSize:15];
        self.ShowQuantity.frame=CGRectMake(112, 2,110, 40);
        self.ShowQuantity.autocorrectionType = UITextAutocorrectionTypeNo;
        self.ShowQuantity.textAlignment = NSTextAlignmentCenter;
        self.ShowQuantity.keyboardType = UIKeyboardTypeDefault;
        self.ShowQuantity.returnKeyType = UIReturnKeyDone;
        self.ShowQuantity.clearButtonMode = UITextFieldViewModeWhileEditing;
        self.ShowQuantity.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        self.ShowQuantity.contentHorizontalAlignment=UIControlContentHorizontalAlignmentCenter;
        self.ShowQuantity.layer.cornerRadius = 1.0f;
        self.ShowQuantity.layer.masksToBounds = YES;
            //    self.ShowQuantity.exclusiveTouch=YES;
        self.ShowQuantity.layer.borderColor = [[UIColor grayColor]CGColor];
        self.ShowQuantity.layer.borderWidth = 2.0f;
        self.ShowQuantity.delegate = self;
        [self addSubview:self.ShowQuantity];
        
        
        self.priceLabel=[[UITextField alloc] init];
        self.priceLabel.font = [UIFont systemFontOfSize:15];
            self.priceLabel.frame=CGRectMake(220, 2, 110, 40);
        self.priceLabel.autocorrectionType = UITextAutocorrectionTypeNo;
        self.priceLabel.textAlignment = NSTextAlignmentCenter;
        self.priceLabel.keyboardType = UIKeyboardTypeDefault;
        self.priceLabel.returnKeyType = UIReturnKeyDone;
        self.priceLabel.clearButtonMode = UITextFieldViewModeWhileEditing;
        self.priceLabel.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        self.priceLabel.contentHorizontalAlignment=UIControlContentHorizontalAlignmentCenter;
//        self.priceLabel.exclusiveTouch=YES;
        self.priceLabel.layer.cornerRadius = 1.0f;
        self.priceLabel.layer.masksToBounds = YES;
        self.priceLabel.layer.borderColor = [[UIColor grayColor]CGColor];
        self.priceLabel.layer.borderWidth = 2.0f;
        self.priceLabel.delegate = self;
        [self addSubview:self.priceLabel];
        
    }
    
    
    return self;
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;

}
-(void)options:(UIButton *)button{

}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
