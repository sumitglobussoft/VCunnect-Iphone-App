//
//  TableViewCell.m
//  NextInsure
//
//  Created by Sumit on 06/02/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {

    // Configure the view for the selected state
        if (![reuseIdentifier isEqualToString:@"OrganizerCell"]) {
        
    
    self.title = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, 80, 20)];
    self.title.textColor = [UIColor blackColor];
    self.title.textAlignment = NSTextAlignmentCenter;
   self.title.font = [UIFont fontWithName:@"Arial" size:14.0f];
        
    self.forShowingTime = [[UILabel alloc] initWithFrame:CGRectMake(80, 5, 200, 20)];
    self.forShowingTime.textColor = [UIColor blackColor];
    self.forShowingTime.textAlignment = NSTextAlignmentCenter;
    self.forShowingTime.font = [UIFont fontWithName:@"Arial" size:14.0f];
    
    self.label3 = [[UILabel alloc] initWithFrame:CGRectMake(80, 30, 150, 20)];
    self.label3.textColor = [UIColor blackColor];
    self.label3.textAlignment = NSTextAlignmentCenter;
    [self.label3 setFont:[UIFont fontWithName:@"Arial-BoldMT" size:15]];
   // self.label3.font = [UIFont fontWithName:@"Arial" size:12.0f];

    self.headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(95, 55, 150, 20)];
    self.headerLabel.textColor = [UIColor blackColor];
    self.headerLabel.font = [UIFont fontWithName:@"Arial" size:14.0f];
        
      //  self.imageView.frame = CGRectMake(0, 20, 20, 20);

        [self addSubview:self.title];
        [self addSubview:self.forShowingTime];
        [self addSubview:self.label3];
        [self addSubview:self.headerLabel];
        
        }else{
        self.organizationDetail=[[UIView alloc] init];
            
            
       
        self.organizationDetail.backgroundColor = [UIColor colorWithRed:(CGFloat)254/255 green:(CGFloat)221/255 blue:(CGFloat)145/255 alpha:1];
        
        self.organizationDetail.layer.shadowColor = [UIColor brownColor].CGColor;
        self.organizationDetail.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
        self.organizationDetail.layer.borderWidth=1.0f;
        self.organizationDetail.layer.shadowOpacity = 0.6f;
        self.organizationDetail.layer.shadowOffset = CGSizeMake(-1.0f, 4.0f);
        self.organizationDetail.layer.shadowRadius = 1.5f;
        self.organizationDetail.layer.masksToBounds = NO;
         [self addSubview:self.organizationDetail];
        
        self.orgnNameLbl=[[UILabel alloc] init];
        self.orgnNameLbl.text = @"Organizer Name";
        self.orgnNameLbl.textColor = [UIColor blackColor];
        self.orgnNameLbl.font = [UIFont fontWithName:nil size:15];
        self.orgnNameLbl.frame = CGRectMake(20,20, 240, 20);
        [self.organizationDetail addSubview:self.orgnNameLbl];
        
        self.orgnNameTxtFld = [[UITextField alloc] init];
        self.orgnNameTxtFld.frame=CGRectMake(20, 40, self.frame.size.width-60, 30);
        self.orgnNameTxtFld.font = [UIFont systemFontOfSize:15];
        self.orgnNameTxtFld.placeholder  = @" Enter organizer Name";
        self.orgnNameTxtFld.autocorrectionType = UITextAutocorrectionTypeNo;
        self.orgnNameTxtFld.keyboardType = UIKeyboardTypeDefault;
        self.orgnNameTxtFld.returnKeyType = UIReturnKeyDone;
        self.orgnNameTxtFld.clearButtonMode = UITextFieldViewModeWhileEditing;
        self.orgnNameTxtFld.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        self.orgnNameTxtFld.backgroundColor=[UIColor whiteColor];
        self.orgnNameTxtFld.layer.cornerRadius = 1.0f;
        self.orgnNameTxtFld.layer.masksToBounds = YES;
        self.orgnNameTxtFld.layer.borderColor = [[UIColor grayColor]CGColor];
        self.orgnNameTxtFld.layer.borderWidth = 2.0f;
        self.orgnNameTxtFld.delegate = self;
        [self.organizationDetail addSubview:self.orgnNameTxtFld];
        self.orgnNameTxtFld.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
        
        
        self.orgnEmailLbl=[[UILabel alloc] init];
        self.orgnEmailLbl.text = @"Organizer Email";
        self.orgnEmailLbl.textColor = [UIColor blackColor];
        self.orgnEmailLbl.font = [UIFont fontWithName:nil size:15];
        self.orgnEmailLbl.frame = CGRectMake(20,80, 200, 20);
        [self.organizationDetail addSubview:self.orgnEmailLbl];
        
        self.orgnEmailTxtFld = [[UITextField alloc] init];
        self.orgnEmailTxtFld.frame=CGRectMake(20, 100, self.frame.size.width-60, 30);
        self.orgnEmailTxtFld.font = [UIFont systemFontOfSize:15];
        self.orgnEmailTxtFld.placeholder  = @" Enter organizer Name";
        self.orgnEmailTxtFld.autocorrectionType = UITextAutocorrectionTypeNo;
        self.orgnEmailTxtFld.keyboardType = UIKeyboardTypeDefault;
        self.orgnEmailTxtFld.returnKeyType = UIReturnKeyDone;
        self.orgnEmailTxtFld.clearButtonMode = UITextFieldViewModeWhileEditing;
        self.orgnEmailTxtFld.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        self.orgnEmailTxtFld.backgroundColor=[UIColor whiteColor];
        self.orgnEmailTxtFld.layer.cornerRadius = 1.0f;
        self.orgnEmailTxtFld.layer.masksToBounds = YES;
        self.orgnEmailTxtFld.layer.borderColor = [[UIColor grayColor]CGColor];
        self.orgnEmailTxtFld.layer.borderWidth = 2.0f;
        self.orgnEmailTxtFld.delegate = self;
        [self.organizationDetail addSubview:self.orgnEmailTxtFld];
        self.orgnEmailTxtFld.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
        
        self.orgnDiscriptionLbl=[[UILabel alloc] init];
        self.orgnDiscriptionLbl.text = @"Organizer Description";
        self.orgnDiscriptionLbl.textColor = [UIColor blackColor];
        self.orgnDiscriptionLbl.font = [UIFont fontWithName:nil size:15];
        self.orgnDiscriptionLbl.frame = CGRectMake(20,150, 220, 20);
        [self.organizationDetail addSubview:self.orgnDiscriptionLbl];
        
        
        self.orgnDiscriptionTxtFld = [[UITextView alloc]init];
        self.orgnDiscriptionTxtFld.font = [UIFont fontWithName:nil size:20];
//        self.orgnDiscriptionTxtFld.textAlignment=NSTextAlignmentCenter;
        self.orgnDiscriptionTxtFld.textColor=[UIColor blackColor];
        self.orgnDiscriptionTxtFld.keyboardType = UIKeyboardTypeAlphabet;
        self.orgnDiscriptionTxtFld.returnKeyType = UIReturnKeyDefault;
       self.orgnDiscriptionTxtFld.delegate=self;
        self.orgnDiscriptionTxtFld.editable = YES;
            self.orgnDiscriptionTxtFld.userInteractionEnabled = YES;
            [self.orgnDiscriptionTxtFld setFont:[UIFont fontWithName:@"ariel" size:15.0]];
        self.orgnDiscriptionTxtFld.frame = CGRectMake(20,170, self.frame.size.width-60, 80);
        [self.organizationDetail addSubview:self.orgnDiscriptionTxtFld];
        self.orgnDiscriptionTxtFld.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
        self.orgnDiscriptionTxtFld.layer.shadowColor = [UIColor brownColor].CGColor;
        self.orgnDiscriptionTxtFld.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
        self.orgnDiscriptionTxtFld.layer.borderWidth=1.0f;
        self.orgnDiscriptionTxtFld.layer.shadowOpacity = 0.6f;
        self.orgnDiscriptionTxtFld.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
        self.orgnDiscriptionTxtFld.layer.shadowRadius = 1.5f;
        self.orgnDiscriptionTxtFld.layer.masksToBounds = NO;
        
            if (IS_IPHONE_6 ) {
                self.organizationDetail.frame=CGRectMake(7, 0, self.frame.size.width+40, 270);
                  self.orgnNameLbl.frame = CGRectMake(50,20, 240, 20);
                self.orgnNameTxtFld.frame=CGRectMake(50, 40, self.frame.size.width-60, 30);
                 self.orgnEmailLbl.frame = CGRectMake(50,80, 200, 20);
                 self.orgnEmailTxtFld.frame=CGRectMake(50, 100, self.frame.size.width-60, 30);
                  self.orgnDiscriptionLbl.frame = CGRectMake(50,150, 220, 20);
                    self.orgnDiscriptionTxtFld.frame = CGRectMake(50,170, self.frame.size.width-60, 80);
            }else if (IS_IPHONE_6P){
                self.organizationDetail.frame=CGRectMake(7, 0, self.frame.size.width+80, 270);
                  self.orgnNameLbl.frame = CGRectMake(70,20, 240, 20);
                self.orgnNameTxtFld.frame=CGRectMake(70, 40, self.frame.size.width-60, 30);
                 self.orgnEmailLbl.frame = CGRectMake(70,80, 200, 20);
                 self.orgnEmailTxtFld.frame=CGRectMake(70, 100, self.frame.size.width-60, 30);
                  self.orgnDiscriptionLbl.frame = CGRectMake(70,150, 220, 20);
                    self.orgnDiscriptionTxtFld.frame = CGRectMake(70,170, self.frame.size.width-60, 80);
            }
            else {
                self.organizationDetail.frame=CGRectMake(7, 0, self.frame.size.width-14, 270);
                  self.orgnNameLbl.frame = CGRectMake(20,20, 240, 20);
                self.orgnNameTxtFld.frame=CGRectMake(20, 40, self.frame.size.width-60, 30);
                 self.orgnEmailLbl.frame = CGRectMake(20,80, 200, 20);
                 self.orgnEmailTxtFld.frame=CGRectMake(20, 100, self.frame.size.width-60, 30);
                  self.orgnDiscriptionLbl.frame = CGRectMake(20,150, 220, 20);
                    self.orgnDiscriptionTxtFld.frame = CGRectMake(20,170, self.frame.size.width-60, 80);
            }
            


        }
        
    }
     return self;
}

@end
