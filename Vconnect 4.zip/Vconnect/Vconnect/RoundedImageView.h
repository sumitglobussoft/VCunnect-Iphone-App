//
//  RoundedImageView.h
//  RoundedImageView
//
//  Created by Danny Shmueli on 9/17/13.
//  Copyright (c) 2013 Danny Shmueli. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RoundedImageView : UIImageView

@end
