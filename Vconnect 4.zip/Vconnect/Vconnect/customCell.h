//
//  customCell.h
//  MoveytProject
//
//  Created by Globussoft 1 on 4/29/14.
//  Copyright (c) 2014 Globussoft 1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface customCell : UITableViewCell<UIActionSheetDelegate,UITextFieldDelegate>{

UITableView *popUpView;

}

@property(nonatomic,strong) UITextField *typeOfTicket;
@property(nonatomic,strong) UITextField *ShowQuantity ;
@property(nonatomic,strong) UITextField *priceLabel ;
@end
