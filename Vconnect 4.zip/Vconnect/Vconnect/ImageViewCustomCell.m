//
//  ImageViewCustomCell.m
//  Anypic
//
//  Created by Globussoft 1 on 9/2/14.
//
//

#import "ImageViewCustomCell.h"
@implementation ImageViewCustomCell
@synthesize imageView,eventDetailLabel,eventTitleLabel;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
       // self.contentView.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"adjustBack.png"]];
        self.imageView=[[UIImageView alloc] initWithFrame:CGRectMake(5, 5, self.frame.size.width-5,self.frame.size.height-50)];
        self.imageView.backgroundColor=[UIColor colorWithRed:17.0/255.0 green:147.0/255.0 blue:132/255.0 alpha:0.5];
        [self.contentView addSubview:self.imageView];
        
        self.eventDetailLabel=[[UILabel alloc]initWithFrame:CGRectMake(5, self.frame.size.height-53, self.frame.size.width-5, 50)];
        self.eventDetailLabel.text=@"event details";
        self.eventDetailLabel.textColor= [UIColor redColor];
        self.eventDetailLabel.backgroundColor=[UIColor whiteColor];
        [self.contentView addSubview:self.eventDetailLabel];
        
        
        self.eventTitleLabel=[[UILabel alloc]initWithFrame:CGRectMake(25,45, 120, 50)];
        self.eventTitleLabel.text=@"Event Details";
        self.eventTitleLabel.textColor= [UIColor whiteColor];
        self.eventTitleLabel.backgroundColor=[UIColor clearColor];
        [self.imageView addSubview:self.eventTitleLabel];

    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
