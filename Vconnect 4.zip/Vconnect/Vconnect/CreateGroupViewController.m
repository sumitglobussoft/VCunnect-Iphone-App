//
//  CreateGroupViewController.m
//  Vconnect
//
//  Created by Globussoft 1 on 4/16/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import "CreateGroupViewController.h"
#import "CreateTicketViewController.h"
#import "AddMoreOrganizer.h"
#import "AFNetworking.h"
#import "MapViewController.h"
#import "UserDefaultHelper.h"

#import <QuartzCore/QuartzCore.h>

@interface CreateGroupViewController ()

@end

@implementation CreateGroupViewController


-(void)viewWillAppear:(BOOL)animated{

     self.navigationController.navigationBarHidden=NO;
    
    self.navigationController.navigationBar.translucent=NO;
    self.navigationController.navigationBar.barTintColor=[UIColor colorWithRed:17.0/255.0 green:147.0/255.0 blue:132.0/255.0 alpha:1.0];
//    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"after_login_bg_320x480.png"]];
 self.navigationController.navigationBar.tintColor=[UIColor whiteColor];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"after_login_bg_320x480.png"]];


    UIBarButtonItem *rightBarItem=[[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(saveButtonAction:)];
    rightBarItem.tintColor=[UIColor whiteColor];
    
    self.navigationController.navigationItem.rightBarButtonItem=rightBarItem;
    [self.navigationItem setRightBarButtonItem:rightBarItem];

    
    self.navigationController.navigationBarHidden=NO;
    NSLog(@"[[[UserDefaultHelper sharedObject] currentLatitude] doubleValue]  %f",[[[UserDefaultHelper sharedObject] currentLatitude] doubleValue]);
     NSLog(@"[[[UserDefaultHelper sharedObject] currentLatitude] doubleValue] %f",[[[UserDefaultHelper sharedObject] currentLongitude] doubleValue]);
    

    self.scrollView=[[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    self.scrollView.delegate=self;
    self.scrollView.backgroundColor=[UIColor clearColor];
    [self.scrollView setContentSize:CGSizeMake(self.view.bounds.size.width, 1700)];
    [self.view addSubview:self.scrollView];

    self.profileImageView=[[UIImageView alloc] initWithFrame:CGRectMake(20, 20, 70, 70)];
    self.profileImageView.image=[UIImage imageNamed:@"profile.png"];
    self.profileImageView.userInteractionEnabled=YES;
    self.profileImageView.layer.borderWidth = 1.5f;
    self.profileImageView.layer.borderColor = [UIColor blackColor].CGColor;
    self.profileImageView.layer.cornerRadius = self.profileImageView.frame.size.width / 2;
    self.profileImageView.clipsToBounds = YES;
    
    UIGestureRecognizer *gesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(getPickureToUpload:)];
    [self.profileImageView setGestureRecognizers:@[gesture]];
    [self.scrollView addSubview:self.profileImageView];
    
    self.eventImgUploadBtn=[UIButton buttonWithType:UIButtonTypeCustom ];
    self.eventImgUploadBtn.frame=CGRectMake(100, 30, 250, 40);
    NSMutableAttributedString *commentString = [[NSMutableAttributedString alloc] initWithString:@"Upload Image for Event Logo"];
    [self.eventImgUploadBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [self.eventImgUploadBtn addTarget:self action:@selector(getPickureToUpload:) forControlEvents:UIControlEventTouchUpInside];
    
    [commentString addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInteger:NSUnderlineStyleSingle] range:NSMakeRange(0, [commentString length])];
    [commentString addAttribute:NSForegroundColorAttributeName value:[UIColor blueColor] range:NSMakeRange(0,[commentString length])];
    
    [self.eventImgUploadBtn setAttributedTitle:commentString forState:UIControlStateNormal];
    [self.scrollView addSubview:self.eventImgUploadBtn];
    
    self.eventTitleLabel=[[UILabel alloc] init];
    self.eventTitleLabel.text = @"Event Title";
    self.eventTitleLabel.textColor = [UIColor blackColor];
    self.eventTitleLabel.font = [UIFont fontWithName:nil size:20];
    self.eventTitleLabel.frame = CGRectMake(20,120, 100, 30);
    [self.scrollView addSubview:self.eventTitleLabel];
    
    self.eventTitleField = [[UITextField alloc] init];
    self.eventTitleField.frame=CGRectMake(15, 150, self.view.frame.size.width-30, 50);
    self.eventTitleField.font = [UIFont systemFontOfSize:15];
    self.eventTitleField.placeholder  = @" Enter Group Name";
    self.eventTitleField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.eventTitleField.keyboardType = UIKeyboardTypeDefault;
    self.eventTitleField.returnKeyType = UIReturnKeyDone;
    self.eventTitleField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.eventTitleField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.eventTitleField.backgroundColor=[UIColor whiteColor];
    self.eventTitleField.layer.cornerRadius = 1.0f;
    self.eventTitleField.layer.masksToBounds = YES;
    self.eventTitleField.layer.borderColor = [[UIColor grayColor]CGColor];
    self.eventTitleField.layer.borderWidth = 2.0f;
    self.eventTitleField.delegate = self;
    [self.scrollView addSubview:self.eventTitleField];
    self.eventTitleField.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];

    self.eventTitleField.layer.shadowColor = [UIColor brownColor].CGColor;
    self.eventTitleField.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.eventTitleField.layer.borderWidth=1.0f;
    self.eventTitleField.layer.shadowOpacity = 0.6f;
    self.eventTitleField.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.eventTitleField.layer.shadowRadius = 1.5f;
    self.eventTitleField.layer.masksToBounds = NO;

    self.locationLabel = [[UILabel alloc]init];
    self.locationLabel.text = @"Event Location";
    self.locationLabel.textColor = [UIColor blackColor];
    self.locationLabel.font = [UIFont fontWithName:nil size:20];
    self.locationLabel.frame = CGRectMake(20, 205, 200, 30);
    [self.scrollView addSubview:self.locationLabel];
    
    self.locationTxtField=[[UITextField alloc] init];
    self.locationTxtField.placeholder  = @" Enter Location ";
    self.locationTxtField.frame=CGRectMake(15, 235, self.view.frame.size.width-30, 50);
    self.locationTxtField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.locationTxtField.keyboardType = UIKeyboardTypeDefault;
    self.locationTxtField.returnKeyType = UIReturnKeyDone;
    self.locationTxtField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.locationTxtField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.locationTxtField.layer.cornerRadius = 1.0f;
    self.locationTxtField.layer.masksToBounds = YES;
    self.locationTxtField.backgroundColor=[UIColor whiteColor];
    self.locationTxtField.layer.borderColor = [[UIColor grayColor]CGColor];
    self.locationTxtField.layer.borderWidth = 2.0f;
    self.locationTxtField.delegate = self;
    [self.scrollView addSubview:self.locationTxtField];
    self.locationTxtField.layer.shadowColor = [UIColor brownColor].CGColor;
    self.locationTxtField.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    
    self.locationTxtField.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.locationTxtField.layer.borderWidth=1.0f;
    self.locationTxtField.layer.shadowOpacity = 0.6f;
    self.locationTxtField.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.locationTxtField.layer.shadowRadius = 1.5f;
    self.locationTxtField.layer.masksToBounds = NO;
    
    self.addressLabel = [[UILabel alloc]init];
    self.addressLabel.text = @"Enter Address";
    self.addressLabel.textColor = [UIColor blackColor];
    self.addressLabel.font = [UIFont fontWithName:nil size:20];
    self.addressLabel.frame = CGRectMake(20,290, 295, 30);
    [self.scrollView addSubview:self.addressLabel];
    
    self.startDate = [[UILabel alloc]init];
    self.startDate.text = @"Start Date & End Date of Event";
    self.startDate.textColor = [UIColor blackColor];
    self.startDate.font = [UIFont fontWithName:nil size:20];
    self.startDate.frame = CGRectMake(20,770, 295, 30);
    [self.scrollView addSubview:self.startDate];
    
    self.datePicker=[[UIDatePicker alloc]initWithFrame:CGRectMake(20, self.view.frame.size.height-200, self.view.frame.size.width-40, 200)];
    
    
    self.startDateField=[[UITextField alloc] init];
    self.startDateField.frame=CGRectMake(10, 800, self.view.frame.size.width/2-20, 50);
    self.startDateField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.startDateField.keyboardType = UIKeyboardTypeDefault;
    self.startDateField.returnKeyType = UIReturnKeyDone;
    self.startDateField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.startDateField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.startDateField.placeholder  = @"Start Date";
    self.startDateField.layer.cornerRadius = 1.0f;
    self.startDateField.layer.masksToBounds = YES;
    self.startDateField.layer.borderColor = [[UIColor grayColor]CGColor];
    self.startDateField.inputView=self.datePicker;
    self.startDateField.layer.borderWidth = 2.0f;
    self.startDateField.delegate = self;
    self.startDateField.font = [UIFont fontWithName:nil size:12];
    [self.scrollView addSubview:self.startDateField];
    self.startDateField.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    self.startDateField.layer.shadowColor = [UIColor brownColor].CGColor;
    self.startDateField.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.startDateField.layer.borderWidth=1.0f;
     self.startDateField.contentHorizontalAlignment=UIControlContentHorizontalAlignmentCenter;
    self.startDateField.layer.shadowOpacity = 0.6f;
    self.startDateField.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.startDateField.layer.shadowRadius = 1.5f;
    self.startDateField.layer.masksToBounds = NO;

    self.endDateField=[[UITextField alloc] init];
    self.endDateField.frame=CGRectMake(self.view.frame.size.width/2, 800, self.view.frame.size.width/2-10, 50);
    self.endDateField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.endDateField.keyboardType = UIKeyboardTypeDefault;
    self.endDateField.returnKeyType = UIReturnKeyDone;
    self.endDateField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.endDateField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.endDateField.placeholder  = @"End Date";
    self.endDateField.layer.cornerRadius = 1.0f;
    self.endDateField.layer.masksToBounds = YES;
    self.endDateField.layer.borderColor = [[UIColor grayColor]CGColor];
    self.endDateField.inputView=self.datePicker;
    self.endDateField.layer.borderWidth = 2.0f;
    self.endDateField.delegate = self;
    self.endDateField.inputView=self.datePicker;
    self.endDateField.contentHorizontalAlignment=UIControlContentHorizontalAlignmentCenter;
     self.endDateField.font = [UIFont fontWithName:nil size:12];
    [self.scrollView addSubview:self.endDateField];
    self.endDateField.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    self.endDateField.layer.shadowColor = [UIColor brownColor].CGColor;
    self.endDateField.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.endDateField.layer.borderWidth=1.0f;
    self.endDateField.layer.shadowOpacity = 0.6f;
    self.endDateField.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.endDateField.layer.shadowRadius = 1.5f;
    self.endDateField.layer.masksToBounds = NO;
    
    toolBar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 56)];
    
    toolBar.barStyle = UIBarStyleBlackOpaque;
    
    [toolBar sizeToFit];
    
    
    NSMutableArray *barItems = [[NSMutableArray alloc] init];
    
    
    UIBarButtonItem *flexSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    
    [barItems addObject:flexSpace];
    
    
    UIBarButtonItem *doneBtn = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(pickerDoneClicked:)];
    
    [barItems addObject:doneBtn];
    
    
    [toolBar setItems:barItems animated:YES];
    self.startDateField.inputAccessoryView=toolBar;
    self.endDateField.inputAccessoryView=toolBar;

    
    self.eventDescription = [[UILabel alloc]init];
    self.eventDescription.text = @"Enter Event Description";
    self.eventDescription.textColor = [UIColor blackColor];
    self.eventDescription.font = [UIFont fontWithName:nil size:20];
    self.eventDescription.frame = CGRectMake(20,865, 295, 30);
    [self.scrollView addSubview:self.eventDescription];

    
    self.eventDescriptionTextView = [[UITextView alloc]init];
    self.eventDescriptionTextView.font = [UIFont fontWithName:nil size:20];
    self.eventDescriptionTextView.textAlignment=NSTextAlignmentCenter;
    self.eventDescriptionTextView.textColor=[UIColor blackColor];
    self.eventDescriptionTextView.keyboardType = UIKeyboardTypeDefault;
    self.eventDescriptionTextView.returnKeyType = UIReturnKeyDone;
    self.eventDescriptionTextView.delegate=self;
      [self.eventDescriptionTextView setText:@"Everything Ok"];
    self.eventDescriptionTextView.frame = CGRectMake(10,895, self.view.frame.size.width-20, 100);
    [self.scrollView addSubview:self.eventDescriptionTextView];
    self.eventDescriptionTextView.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    self.eventDescriptionTextView.layer.shadowColor = [UIColor brownColor].CGColor;
    self.eventDescriptionTextView.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.eventDescriptionTextView.layer.borderWidth=1.0f;
    self.eventDescriptionTextView.layer.shadowOpacity = 0.6f;
    self.eventDescriptionTextView.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.eventDescriptionTextView.layer.shadowRadius = 1.5f;
    self.eventDescriptionTextView.layer.masksToBounds = NO;

    
    self.createTicketForEvent=[UIButton buttonWithType:UIButtonTypeCustom ];
    self.createTicketForEvent.frame=CGRectMake(40, 1390, 250, 40);
    NSMutableAttributedString *commentStr = [[NSMutableAttributedString alloc] initWithString:@"Create Ticket For Event"];
    [self.createTicketForEvent setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [self.createTicketForEvent addTarget:self action:@selector(createTicketForEventClick) forControlEvents:UIControlEventTouchUpInside];
    
    [commentStr addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInteger:NSUnderlineStyleSingle] range:NSMakeRange(0, [commentStr length])];
    [commentStr addAttribute:NSForegroundColorAttributeName value:[UIColor blueColor] range:NSMakeRange(0,[commentStr length])];
    
    [self.createTicketForEvent setAttributedTitle:commentStr forState:UIControlStateNormal];
    [self.scrollView addSubview:self.createTicketForEvent];
    
    
    self.showMapViewButton=[UIButton buttonWithType:UIButtonTypeCustom ];
    self.showMapViewButton.frame=CGRectMake(40, 1450, 250, 40);
    NSMutableAttributedString *titleStr = [[NSMutableAttributedString alloc] initWithString:@"Show Location on Map"];
    [self.showMapViewButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [self.showMapViewButton addTarget:self action:@selector(showMapButtonClick) forControlEvents:UIControlEventTouchUpInside];
    
    [titleStr addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInteger:NSUnderlineStyleSingle] range:NSMakeRange(0, [titleStr length])];
    [titleStr addAttribute:NSForegroundColorAttributeName value:[UIColor blueColor] range:NSMakeRange(0,[titleStr length])];
    
    [self.showMapViewButton setAttributedTitle:titleStr forState:UIControlStateNormal];
    [self.scrollView addSubview:self.showMapViewButton];

//    =============================-==========-===========-==========-========-======
    
    self.orgnDeclareLabel = [[UILabel alloc]init];
    self.orgnDeclareLabel.text = @"Organizer Detail";
    self.orgnDeclareLabel.textColor = [UIColor blackColor];
    self.orgnDeclareLabel.font = [UIFont fontWithName:nil size:20];
    self.orgnDeclareLabel.frame = CGRectMake(20,1010, 205, 30);
    [self.scrollView addSubview:self.orgnDeclareLabel];

    
    self.orgnAddBtn=[UIButton buttonWithType:UIButtonTypeCustom];
    [self.orgnAddBtn addTarget:self action:@selector(createNewOrganizer:) forControlEvents:UIControlEventTouchUpInside];
//    [self.orgnAddBtn setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
//    [self.orgnAddBtn setTitle:@"Add more Organizer" forState:UIControlStateNormal];
    self.orgnAddBtn.frame=CGRectMake(45, 1360, 260, 40);
    NSMutableAttributedString *orgnStr = [[NSMutableAttributedString alloc] initWithString:@"Add more Organizer"];
    
    [orgnStr addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInteger:NSUnderlineStyleSingle] range:NSMakeRange(0, [orgnStr length])];
    [orgnStr addAttribute:NSForegroundColorAttributeName value:[UIColor blueColor] range:NSMakeRange(0,[orgnStr length])];
    
    [self.orgnAddBtn setAttributedTitle:orgnStr forState:UIControlStateNormal];
    [self.scrollView addSubview:self.orgnAddBtn];

    
    self.organizationDetail=[[UIView alloc] init];
    self.organizationDetail.frame=CGRectMake(7, 1045, self.view.frame.size.width-14, 270);
  
    [self.scrollView addSubview:self.organizationDetail];
    self.organizationDetail.backgroundColor = [UIColor colorWithRed:(CGFloat)254/255 green:(CGFloat)221/255 blue:(CGFloat)145/255 alpha:1];
    
    self.organizationDetail.layer.shadowColor = [UIColor brownColor].CGColor;
    self.organizationDetail.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.organizationDetail.layer.borderWidth=1.0f;
    self.organizationDetail.layer.shadowOpacity = 0.6f;
    self.organizationDetail.layer.shadowOffset = CGSizeMake(-1.0f, 4.0f);
    self.organizationDetail.layer.shadowRadius = 1.5f;
    self.organizationDetail.layer.masksToBounds = NO;

    
    self.orgnNameLbl=[[UILabel alloc] init];
    self.orgnNameLbl.text = @"Organizer Name";
    self.orgnNameLbl.textColor = [UIColor blackColor];
    self.orgnNameLbl.font = [UIFont fontWithName:nil size:15];
    self.orgnNameLbl.frame = CGRectMake(20,20, 240, 20);
    [self.organizationDetail addSubview:self.orgnNameLbl];
    
    self.orgnNameTxtFld = [[UITextField alloc] init];
    self.orgnNameTxtFld.frame=CGRectMake(20, 40, self.view.frame.size.width-60, 30);
    self.orgnNameTxtFld.font = [UIFont systemFontOfSize:15];
    self.orgnNameTxtFld.placeholder  = @" Enter organization Name";
    self.orgnNameTxtFld.autocorrectionType = UITextAutocorrectionTypeNo;
    self.orgnNameTxtFld.keyboardType = UIKeyboardTypeDefault;
    self.orgnNameTxtFld.returnKeyType = UIReturnKeyDone;
    self.orgnNameTxtFld.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.orgnNameTxtFld.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.orgnNameTxtFld.backgroundColor=[UIColor whiteColor];
    self.orgnNameTxtFld.layer.cornerRadius = 1.0f;
    self.orgnNameTxtFld.layer.masksToBounds = YES;
    self.orgnNameTxtFld.layer.borderColor = [[UIColor grayColor]CGColor];
    self.orgnNameTxtFld.layer.borderWidth = 2.0f;
    self.orgnNameTxtFld.delegate = self;
    [self.organizationDetail addSubview:self.orgnNameTxtFld];
    self.orgnNameTxtFld.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    
    
    self.orgnEmailLbl=[[UILabel alloc] init];
    self.orgnEmailLbl.text = @"Organizer Email";
    self.orgnEmailLbl.textColor = [UIColor blackColor];
    self.orgnEmailLbl.font = [UIFont fontWithName:nil size:15];
    self.orgnEmailLbl.frame = CGRectMake(20,80, 200, 20);
    [self.organizationDetail addSubview:self.orgnEmailLbl];
    
    self.orgnEmailTxtFld = [[UITextField alloc] init];
    self.orgnEmailTxtFld.frame=CGRectMake(20, 100, self.view.frame.size.width-60, 30);
    self.orgnEmailTxtFld.font = [UIFont systemFontOfSize:15];
    self.orgnEmailTxtFld.placeholder  = @" Enter organizer Name";
    self.orgnEmailTxtFld.autocorrectionType = UITextAutocorrectionTypeNo;
    self.orgnEmailTxtFld.keyboardType = UIKeyboardTypeDefault;
    self.orgnEmailTxtFld.returnKeyType = UIReturnKeyDone;
    self.orgnEmailTxtFld.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.orgnEmailTxtFld.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.orgnEmailTxtFld.backgroundColor=[UIColor whiteColor];
    self.orgnEmailTxtFld.layer.cornerRadius = 1.0f;
    self.orgnEmailTxtFld.layer.masksToBounds = YES;
    self.orgnEmailTxtFld.layer.borderColor = [[UIColor grayColor]CGColor];
    self.orgnEmailTxtFld.layer.borderWidth = 2.0f;
    self.orgnEmailTxtFld.delegate = self;
    [self.organizationDetail addSubview:self.orgnEmailTxtFld];
    self.orgnEmailTxtFld.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    
    self.orgnDiscriptionLbl=[[UILabel alloc] init];
    self.orgnDiscriptionLbl.text = @"Organizer Description";
    self.orgnDiscriptionLbl.textColor = [UIColor blackColor];
    self.orgnDiscriptionLbl.font = [UIFont fontWithName:nil size:15];
    self.orgnDiscriptionLbl.frame = CGRectMake(20,150, 220, 20);
    [self.organizationDetail addSubview:self.orgnDiscriptionLbl];
    
    
    self.orgnDiscriptionTxtFld = [[UITextView alloc]init];
    self.orgnDiscriptionTxtFld.font = [UIFont fontWithName:nil size:20];
    self.orgnDiscriptionTxtFld.textAlignment=NSTextAlignmentCenter;
    self.orgnDiscriptionTxtFld.textColor=[UIColor blackColor];
    self.orgnDiscriptionTxtFld.keyboardType = UIKeyboardTypeDefault;
    self.orgnDiscriptionTxtFld.returnKeyType = UIReturnKeyDone;
    self.orgnDiscriptionTxtFld.delegate=self;
     [self.orgnDiscriptionTxtFld setText:@"Everything Ok"];
    
    self.orgnDiscriptionTxtFld.frame = CGRectMake(20,170, self.view.frame.size.width-60, 80);
    [self.organizationDetail addSubview:self.orgnDiscriptionTxtFld];
    self.orgnDiscriptionTxtFld.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    self.orgnDiscriptionTxtFld.layer.shadowColor = [UIColor brownColor].CGColor;
    self.orgnDiscriptionTxtFld.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.orgnDiscriptionTxtFld.layer.borderWidth=1.0f;
    self.orgnDiscriptionTxtFld.layer.shadowOpacity = 0.6f;
    self.orgnDiscriptionTxtFld.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.orgnDiscriptionTxtFld.layer.shadowRadius = 1.5f;
    self.orgnDiscriptionTxtFld.layer.masksToBounds = NO;

    //    =============================-==========-===========-==========-========-======
    
    self.addressDetailView=[[UIView alloc] init];
    self.addressDetailView.frame=CGRectMake(7, 320, self.view.frame.size.width-14, 440);
    
    [self.scrollView addSubview:self.addressDetailView];
    self.addressDetailView.backgroundColor = [UIColor colorWithRed:(CGFloat)254/255 green:(CGFloat)221/255 blue:(CGFloat)145/255 alpha:1];
    
    self.addressDetailView.layer.shadowColor = [UIColor brownColor].CGColor;
    self.addressDetailView.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.addressDetailView.layer.borderWidth=1.0f;
    self.addressDetailView.layer.shadowOpacity = 0.6f;
    self.addressDetailView.layer.shadowOffset = CGSizeMake(-1.0f, 4.0f);
    self.addressDetailView.layer.shadowRadius = 1.5f;
    self.addressDetailView.layer.masksToBounds = NO;
    
    
    self.addressTxtField=[[UITextField alloc] init];
    self.addressTxtField.frame=CGRectMake(15, 20, self.view.frame.size.width-50, 30);
    self.addressTxtField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.addressTxtField.keyboardType = UIKeyboardTypeDefault;
    self.addressTxtField.returnKeyType = UIReturnKeyDone;
    self.addressTxtField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.addressTxtField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.addressTxtField.placeholder  = @" Enter Event Address ";
    self.addressTxtField.layer.cornerRadius = 1.0f;
    self.addressTxtField.layer.masksToBounds = YES;
    self.addressTxtField.layer.borderColor = [[UIColor grayColor]CGColor];
    self.addressTxtField.layer.borderWidth = 2.0f;
    self.addressTxtField.delegate = self;
    [self.addressDetailView addSubview:self.addressTxtField];
    self.addressTxtField.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    
    self.addressTxtField.layer.shadowColor = [UIColor brownColor].CGColor;
    self.addressTxtField.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.addressTxtField.layer.borderWidth=1.0f;
    self.addressTxtField.layer.shadowOpacity = 0.6f;
    self.addressTxtField.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.addressTxtField.layer.shadowRadius = 1.5f;
    self.addressTxtField.layer.masksToBounds = NO;
    

    self.vanueLabel = [[UILabel alloc]init];
    self.vanueLabel.text = @"Event Vanue";
    self.vanueLabel.textColor = [UIColor blackColor];
    self.vanueLabel.font = [UIFont fontWithName:nil size:15];
    self.vanueLabel.frame = CGRectMake(20,70, 295, 20);
    [self.addressDetailView addSubview:self.vanueLabel];
        //
    
    
    self.vanueField=[[UITextField alloc] init];
    self.vanueField.placeholder  = @" Enter Vanue of Event";
    self.vanueField.frame=CGRectMake(15, 90, self.view.frame.size.width-50, 30);
    self.vanueField.autocorrectionType = UITextAutocorrectionTypeNo;
    self.vanueField.keyboardType = UIKeyboardTypeDefault;
    self.vanueField.returnKeyType = UIReturnKeyDone;
    self.vanueField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.vanueField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.vanueField.layer.cornerRadius = 1.0f;
    self.vanueField.layer.masksToBounds = YES;
    self.vanueField.layer.borderColor = [[UIColor grayColor]CGColor];
    self.vanueField.layer.borderWidth = 2.0f;
    self.vanueField.delegate = self;
    [self.addressDetailView addSubview:self.vanueField];
    self.vanueField.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    
    self.vanueField.layer.shadowColor = [UIColor brownColor].CGColor;
    self.vanueField.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.vanueField.layer.borderWidth=1.0f;
    self.vanueField.layer.shadowOpacity = 0.6f;
    self.vanueField.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.vanueField.layer.shadowRadius = 1.5f;
    self.vanueField.layer.masksToBounds = NO;

    
    
    self.address1Lbl=[[UILabel alloc] init];
    self.address1Lbl.text = @"Address1";
    self.address1Lbl.textColor = [UIColor blackColor];
    self.address1Lbl.font = [UIFont fontWithName:nil size:15];
    self.address1Lbl.frame = CGRectMake(20,130, 240, 20);
    [self.addressDetailView addSubview:self.address1Lbl];
    
    self.address1Field = [[UITextField alloc] init];
self.address1Field.frame=CGRectMake(20, 150, self.view.frame.size.width-60, 30);
    self.address1Field.font = [UIFont systemFontOfSize:15];
    self.address1Field.placeholder  = @" Enter Address1 ";
    self.address1Field.autocorrectionType = UITextAutocorrectionTypeNo;
    self.address1Field.keyboardType = UIKeyboardTypeDefault;
    self.address1Field.returnKeyType = UIReturnKeyDone;
    self.address1Field.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.address1Field.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.address1Field.backgroundColor=[UIColor whiteColor];
    self.address1Field.layer.cornerRadius = 1.0f;
    self.address1Field.layer.masksToBounds = YES;
    self.address1Field.layer.borderColor = [[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1]CGColor];
    self.address1Field.layer.borderWidth = 2.0f;
    self.address1Field.delegate = self;
    [self.addressDetailView addSubview:self.address1Field];
    self.address1Field.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    self.address1Field.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.address1Field.layer.borderWidth=1.0f;
    self.address1Field.layer.shadowOpacity = 0.6f;
    self.address1Field.layer.shadowColor=[[UIColor brownColor] CGColor];
    self.address1Field.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.address1Field.layer.shadowRadius = 1.5f;
    self.address1Field.layer.masksToBounds = NO;
    
    self.address2Lbl=[[UILabel alloc] init];
    self.address2Lbl.text = @" Address2 ";
    self.address2Lbl.textColor = [UIColor blackColor];
    self.address2Lbl.font = [UIFont fontWithName:nil size:15];
    self.address2Lbl.frame = CGRectMake(20,190, 200, 20);
    [self.addressDetailView addSubview:self.address2Lbl];
    
    self.address2Field = [[UITextField alloc] init];
    self.address2Field.frame=CGRectMake(20, 210, self.view.frame.size.width-60, 30);
    self.address2Field.font = [UIFont systemFontOfSize:15];
    self.address2Field.placeholder  = @" Enter organization Name";
    self.address2Field.autocorrectionType = UITextAutocorrectionTypeNo;
    self.address2Field.keyboardType = UIKeyboardTypeDefault;
    self.address2Field.returnKeyType = UIReturnKeyDone;
    self.address2Field.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.address2Field.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.address2Field.backgroundColor=[UIColor whiteColor];
    self.address2Field.layer.cornerRadius = 1.0f;
    self.address2Field.layer.masksToBounds = YES;
    self.address2Field.layer.borderColor = [[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1]CGColor];
    self.address2Field.layer.borderWidth = 2.0f;
    self.address2Field.delegate = self;
    [self.addressDetailView addSubview:self.address2Field];
    self.address2Field.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    
    self.address2Field.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.address2Field.layer.borderWidth=1.0f;
    self.address2Field.layer.shadowOpacity = 0.6f;
    self.address2Field.layer.shadowColor=[[UIColor brownColor] CGColor];
    self.address2Field.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.address2Field.layer.shadowRadius = 1.5f;
    self.address2Field.layer.masksToBounds = NO;
    
    
    self.cityLbl=[[UILabel alloc] init];
    self.cityLbl.text = @"City Name";
    self.cityLbl.textColor = [UIColor blackColor];
    self.cityLbl.font = [UIFont fontWithName:nil size:15];
    self.cityLbl.frame = CGRectMake(20,250, 220, 20);
    [self.addressDetailView addSubview:self.cityLbl];
    
    
    self.cityField = [[UITextField alloc]init];
    self.cityField.font = [UIFont fontWithName:nil size:20];
    self.cityField.textAlignment=NSTextAlignmentCenter;
    self.cityField.textColor=[UIColor blackColor];
    self.cityField.keyboardType = UIKeyboardTypeDefault;
    self.cityField.returnKeyType = UIReturnKeyDone;
    self.cityField.delegate=self;
    self.cityField.frame = CGRectMake(20,270, self.view.frame.size.width-60, 30);
    [self.addressDetailView addSubview:self.cityField];
    self.cityField.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    self.cityField.layer.shadowColor = [UIColor brownColor].CGColor;
    self.cityField.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.cityField.layer.borderWidth=1.0f;
    self.cityField.layer.shadowOpacity = 0.6f;
    self.cityField.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.cityField.layer.shadowRadius = 1.5f;
    self.cityField.layer.masksToBounds = NO;
    
    
    
    self.StateLbl=[[UILabel alloc] init];
    self.StateLbl.text = @"State Name";
    self.StateLbl.textColor = [UIColor blackColor];
    self.StateLbl.font = [UIFont fontWithName:nil size:15];
    self.StateLbl.frame = CGRectMake(20,310, 220, 20);
   [self.addressDetailView addSubview:self.StateLbl];
    
    
    self.StateField = [[UITextField alloc]init];
    self.StateField.font = [UIFont fontWithName:nil size:20];
    self.StateField.textAlignment=NSTextAlignmentCenter;
    self.StateField.textColor=[UIColor blackColor];
    self.StateField.keyboardType = UIKeyboardTypeDefault;
    self.StateField.returnKeyType = UIReturnKeyDone;
    self.StateField.delegate=self;
    self.StateField.frame = CGRectMake(20,330, self.view.frame.size.width-60, 30);
   [self.addressDetailView addSubview:self.StateField];
    self.StateField.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    self.StateField.layer.shadowColor = [UIColor brownColor].CGColor;
    self.StateField.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.StateField.layer.borderWidth=1.0f;
    self.StateField.layer.shadowOpacity = 0.6f;
    self.StateField.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.StateField.layer.shadowRadius = 1.5f;
    self.StateField.layer.masksToBounds = NO;
    
    
    self.countryLbl=[[UILabel alloc] init];
    self.countryLbl.text = @"Country Name";
    self.countryLbl.textColor = [UIColor blackColor];
    self.countryLbl.font = [UIFont fontWithName:nil size:15];
    self.countryLbl.frame = CGRectMake(20,370, 220, 20);
    [self.addressDetailView addSubview:self.countryLbl];
    
    
    self.countryField = [[UITextField alloc]init];
    self.countryField.font = [UIFont fontWithName:nil size:20];
    self.countryField.textAlignment=NSTextAlignmentCenter;
    self.countryField.textColor=[UIColor blackColor];
    self.countryField.keyboardType = UIKeyboardTypeDefault;
    self.countryField.returnKeyType = UIReturnKeyDone;
    self.countryField.delegate=self;
    self.countryField.frame = CGRectMake(20,390, self.view.frame.size.width-60, 30);
    [self.addressDetailView addSubview:self.countryField];
    self.countryField.backgroundColor = [UIColor colorWithRed:(CGFloat)215/255 green:(CGFloat)229/255 blue:(CGFloat)178/255 alpha:1];
    self.countryField.layer.shadowColor = [UIColor brownColor].CGColor;
    self.countryField.layer.borderColor=[[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1] CGColor];
    self.countryField.layer.borderWidth=1.0f;
    self.countryField.layer.shadowOpacity = 0.6f;
    self.countryField.layer.shadowOffset = CGSizeMake(1.0f, 4.0f);
    self.countryField.layer.shadowRadius = 1.5f;
    self.countryField.layer.masksToBounds = NO;
    
    // Do any additional setup after loading the view.
}


-(void)createNewOrganizer:(UIButton *)button{
    if (!self.addmoreOrgnizer) {
        self.addmoreOrgnizer=[[AddMoreOrganizer alloc] init];
        self.addmoreOrgnizer.title=@"Add Organizer";
        self.addmoreOrgnizer.delegate=self;

    }
        [self.navigationController pushViewController:self.addmoreOrgnizer animated:YES];
}


-(void)pickerDoneClicked:(UIBarButtonItem *)picker{
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd-MM-yyyy hh:mm:ss a"];
    BOOL isTrue=[self.startDateField isFirstResponder];
    if (isTrue) {
        self.startDateValue=self.datePicker.date;
        self.startDateField.text=[dateFormatter stringFromDate:self.datePicker.date ];
         [dateFormatter setDateFormat:@"dd-MM-yyyy"];
        self.startDateStr=[dateFormatter stringFromDate:self.datePicker.date];
       
         [dateFormatter setDateFormat:@"hh:mm:ss a"];
        self.startTimeStr=[dateFormatter stringFromDate:self.datePicker.date];
        [self.startDateField resignFirstResponder];
    }else{
        self.endDateValue=self.datePicker.date;

        self.endDateField.text=[dateFormatter stringFromDate:self.datePicker.date ];
        [dateFormatter setDateFormat:@"dd-MM-yyyy"];

         self.endDateStr=[dateFormatter stringFromDate:self.datePicker.date];
          [dateFormatter setDateFormat:@"hh:mm:ss a"];
         self.endTimeStr=[dateFormatter stringFromDate:self.datePicker.date];
        [self.endDateField resignFirstResponder];
    }
  
}

-(void)showMapButtonClick{
    
    if (!self.mapViewController) {
        self.mapViewController=[[MapViewController alloc] init];
    }
    
    [self.navigationController pushViewController:self.mapViewController animated:YES];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return YES;
    }
       return YES;
}


-(void)textViewDidBeginEditing:(UITextView *)textView{

    self.scrollView.contentOffset=CGPointMake(0,500);
}

-(void)textViewDidEndEditing:(UITextView *)textView{
    
    self.scrollView.contentOffset=CGPointMake(0, 200);
}
-(void)createTicketForEventClick{
    if (!self.createTicketView) {
    self.createTicketView=[[CreateTicketViewController alloc] init];
        self.createTicketView.title=@"Create Ticket";
        self.createTicketView.ticketDelegate=self;

    }
       [self.navigationController pushViewController:self.createTicketView animated:YES];
    
}

-(void)getPickureToUpload:(UIButton *)button{

    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:picker animated:YES completion:NULL];

}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    self.profileImageView.image = chosenImage;
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    if(textField==self.startDateField||textField==self.endDateField){
        self.scrollView.contentOffset=CGPointMake(0, 200);
    }
    
  textField.layer.borderColor = [[UIColor blueColor]CGColor];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
-(void)textFieldDidEndEditing:(UITextField *)textField{

    if(textField==self.startDateField||textField==self.endDateField){
        self.scrollView.contentOffset=CGPointMake(0, 0);
    }
    textField.layer.borderColor=[[UIColor grayColor] CGColor];
}

-(void)saveButtonAction:(UIBarButtonItem *)barButton{

    NSMutableDictionary *dictParam=[[NSMutableDictionary alloc]init];
    [dictParam setObject:@"InsertEvents" forKey:@"method"];
    [dictParam setObject:@"me" forKey:@"createdby"];
    [dictParam setObject:self.eventTitleField.text forKey:@"name"];
    [dictParam setObject:self.locationTxtField.text forKey:@"location"];
        [dictParam setObject:self.vanueField.text forKey:@"venuename"];
    [dictParam setObject:self.address1Field.text forKey:@"address1"];
     [dictParam setObject:self.address2Field.text forKey:@"address2"];
        [dictParam setObject:self.cityField.text forKey:@"city"];
    [dictParam setObject:self.StateField.text forKey:@"state"];
    [dictParam setObject:self.countryField.text forKey:@"country"];
    [dictParam setObject:self.addressTxtField.text forKey:@"address"];

    [dictParam setObject:@"Hello" forKey:@"description"];
    [dictParam setObject:[UserDefaultHelper sharedObject].currentLatitude forKey:@"lat"];
    [dictParam setObject:[UserDefaultHelper sharedObject].currentLongitude forKey:@"lng"];

    [dictParam setObject:self.startDateStr  forKey:@"startdate"];
    [dictParam setObject:self.endDateStr forKey:@"enddate"];
    [dictParam setObject:self.startTimeStr forKey:@"starttime"];
    [dictParam setObject:self.endTimeStr forKey:@"endtime"];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc]init];
    [dict setObject:self.orgnNameTxtFld.text forKey:@"name"];
    [dict setObject:self.orgnEmailTxtFld.text forKey:@"organiseremail"];
    [dict setObject:self.orgnDiscriptionTxtFld.text forKey:@"organiserdescription"];

    NSMutableArray *array = [[NSMutableArray alloc]init];
    [array addObject:dict];
    
    [dictParam setObject:array forKey:@"organisers"];
//    [dictParam setObject:self.orgnEmailTxtFld.text forKey:@"organiseremail"];
//    [dictParam setObject:self.orgnDiscriptionTxtFld.text forKey:@"organiserdescription"];
    
    
    [dictParam setObject: [NSString stringWithFormat:@"%f",[self.startDateValue timeIntervalSince1970] ] forKey:@"starttimestamp"];
    [dictParam setObject:[NSString stringWithFormat:@"%f",[self.endDateValue timeIntervalSince1970] ]  forKey:@"endtimestamp"];

       AFNHelper *afn=[[AFNHelper alloc]initWithRequestMethod:GET_METHOD];
    [afn getDataFromPath:nil withParamData:dictParam withBlock:^(id response, NSError *error)
     {
         NSLog(@"reponse is ====%@",response);
         
     }];

}

-(void)sendOrganizerDetailArray:(NSArray *)taglistArray{


}
-(void)sendTicketDetailArray:(NSArray *)taglistArray{

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
