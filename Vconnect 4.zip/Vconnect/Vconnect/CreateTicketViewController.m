//
//  CreateTicketViewController.m
//  Vconnect
//
//  Created by Globussoft 1 on 4/17/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import "CreateTicketViewController.h"
#import "customCell.h"

@interface CreateTicketViewController ()

@end

@implementation CreateTicketViewController
@synthesize ticketDelegate;
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.ticketPriceArr=[[NSMutableArray alloc] init];
    self.ticketQuantityArr=[[NSMutableArray alloc] init];
    self.ticketTypeArr=[[NSMutableArray alloc] init];
    self.ticketDetailArr=[[NSMutableArray alloc] init];
    
    UIBarButtonItem *rightBarItem=[[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(doneButtonAction:)];
    rightBarItem.tintColor=[UIColor whiteColor];
    
    self.navigationController.navigationItem.rightBarButtonItem=rightBarItem;
    [self.navigationItem setRightBarButtonItem:rightBarItem];
    
    self.tableDatalist=[[NSMutableArray alloc]init];
    [self.tableDatalist addObject:@"One"];
    [self.tableDatalist addObject:@"Two"];
    
    self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"after_login_bg_320x480.png"]];
   self.tableView=[[UITableView alloc] initWithFrame:CGRectMake(0, 5, self.view.frame.size.width, self.view.frame.size.height-100)];
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor=[UIColor clearColor];
   [self.view addSubview:self.tableView];
    
    UIButton *createAccount = [UIButton buttonWithType:UIButtonTypeCustom];
    createAccount.frame = CGRectMake(0, 5, self.tableView.frame.size.width, 40);
    createAccount.titleLabel.font = [UIFont systemFontOfSize:20.0f];
    createAccount.backgroundColor=[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1];
    [createAccount setTitle:@"  Create More Ticket"  forState:UIControlStateNormal];
    createAccount.titleLabel.textColor=[UIColor whiteColor];
    [createAccount setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    createAccount.layer.borderColor=[[UIColor whiteColor] CGColor];
    createAccount.layer.borderWidth=1.5;

    [createAccount addTarget:self action:@selector(createNewTicket:) forControlEvents:UIControlEventTouchUpInside];
    static NSString *CellIdentifier = @"Cell";
    self.tableView.tableFooterView=createAccount;
    self.tableView.tableFooterView.userInteractionEnabled=YES;
//    [self.tableView registerClass:[customCell class] forCellReuseIdentifier:CellIdentifier];
    // Do any additional setup after loading the view.
}


-(void)doneButtonAction:(UIBarButtonItem *)baritem{
    
    NSIndexPath *index=[NSIndexPath indexPathForRow:self.currentSelectedInedx inSection:0];
    
    customCell *cell=(customCell *)[self.tableView cellForRowAtIndexPath:index];
    [cell.typeOfTicket resignFirstResponder];
    [cell.priceLabel resignFirstResponder];
    [cell.ShowQuantity resignFirstResponder];
    
        //    if (self.nameArray.count==self.emailArray.count==self.descriptionArray.count) {
    for (int i=0; i<self.ticketPriceArr.count; i++) {
        NSMutableDictionary *dict=[[NSMutableDictionary alloc] init];
        [dict setObject:[self.ticketPriceArr objectAtIndex:i] forKey:@"price"];
        [dict setObject:[self.ticketQuantityArr objectAtIndex:i] forKey:@"quantity"];
        [dict setObject:[self.ticketTypeArr objectAtIndex:i] forKey:@"name"];
        [self.ticketDetailArr insertObject:dict atIndex:i];
        
    }

    NSLog(@"ticket Detail  %@",self.ticketDetailArr);
  [self.navigationController popViewControllerAnimated:YES];
    
    
}

-(void)createNewTicket:(UIButton *)button{
    
    [self.tableView reloadData];
    if (self.tableDatalist.count==11) {
        return;
    }
    
        dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView beginUpdates];
     [self.tableDatalist insertObject:@"Hello" atIndex:self.tableDatalist.count-1];
        
        
            if (self.tableDatalist.count>9) {
                self.tableView.contentOffset=CGPointMake(0,self.tableView.contentOffset.x+ 200);
            }
        [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.tableDatalist.count-1 inSection:0]]
                              withRowAnimation:UITableViewRowAnimationRight];
        
       
        [self.tableView endUpdates];
    });
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.tableDatalist.count;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    [tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
//    
[tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void) textFieldDidBeginEditing:(UITextField *)textField {
    self.currentSelectedInedx=textField.tag;
    self.tableView.contentOffset =  CGPointMake(0, 500);

  
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
// self.tableView.contentInset =  UIEdgeInsetsMake(0, 0, 0, 0);
     self.tableView.contentOffset =   CGPointMake(0, 0);
    
    
    NSIndexPath *index=[NSIndexPath indexPathForRow:self.currentSelectedInedx-1 inSection:0];
    customCell *cell=(customCell *)[self.tableView cellForRowAtIndexPath:index];
    
    if (![textField.text isEqualToString:@""]) {
        
        if (cell.typeOfTicket==textField) {
            [self.ticketTypeArr insertObject:textField.text atIndex:self.currentSelectedInedx-1];
            NSLog(@"textfield %@",[self.ticketTypeArr objectAtIndex:self.currentSelectedInedx-1]);
        }
        if (cell.priceLabel==textField) {
            [self.ticketPriceArr insertObject:textField.text atIndex:self.currentSelectedInedx-1];
            NSLog(@"textfield %@",[self.ticketPriceArr objectAtIndex:self.currentSelectedInedx-1]);
            
        }
        
        if (cell.ShowQuantity==textField) {
            [self.ticketQuantityArr insertObject:textField.text atIndex:self.currentSelectedInedx-1];
            NSLog(@"textfield %@",[self.ticketPriceArr objectAtIndex:self.currentSelectedInedx-1]);

        }
        
    }

}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.tableDatalist removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationMiddle];
        
        [tableView endUpdates];
        [tableView reloadData];
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        return NO;
    }else{
    
        return YES;
    }

}

-(void)viewWillAppear:(BOOL)animated{


}
-(void)viewDidDisappear:(BOOL)animated{
    [ticketDelegate sendTicketDetailArray:self.ticketDetailArr];

}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"Cell";
    
    customCell *cell = (customCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[customCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.ShowQuantity.frame=CGRectMake(3, 2, self.tableView.frame.size.width/3, 40);
    
    cell.typeOfTicket.frame=CGRectMake(self.tableView.frame.size.width/3+5, 2, self.tableView.frame.size.width/3, 40);
    cell.priceLabel.frame=CGRectMake((2*self.tableView.frame.size.width)/3+7, 2, self.tableView.frame.size.width/3-10, 40);
    cell.priceLabel.delegate=self;
    cell.ShowQuantity.delegate=self;
    cell.typeOfTicket.delegate=self;
    cell.priceLabel.contentVerticalAlignment = UIControlContentHorizontalAlignmentCenter;
    cell.typeOfTicket.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    cell.ShowQuantity.contentVerticalAlignment = UIControlContentHorizontalAlignmentCenter;
    cell.ShowQuantity.textAlignment = NSTextAlignmentCenter;
    cell.ShowQuantity.textColor=[UIColor blackColor];
    cell.typeOfTicket.textColor=[UIColor blackColor];
    cell.priceLabel.textColor=[UIColor blackColor];
    cell.ShowQuantity.tag=indexPath.row;
    cell.typeOfTicket.tag=indexPath.row;
    cell.priceLabel.tag=indexPath.row;
    if (indexPath.row==0) {
      
        cell.ShowQuantity.placeholder=@"QuantityAvilable";
        cell.typeOfTicket.placeholder=@"TicketType";
        cell.priceLabel.placeholder=@"Price";
        
        cell.backgroundColor=[UIColor colorWithRed:215.0/255.0 green:229.0/255.0 blue:178.0/255.0 alpha:1.0];
        cell.priceLabel.enabled=NO;
        cell.ShowQuantity.enabled=NO;
        cell.typeOfTicket.enabled=NO;
    }else{
        cell.ShowQuantity.placeholder=@"EnterQuantity";
        cell.typeOfTicket.placeholder=@"EnterType";
        cell.priceLabel.placeholder=@"EnterPrice";
        cell.backgroundColor=[UIColor whiteColor];
        
        if (indexPath.row-1<self.ticketPriceArr.count) {
            cell.priceLabel.text=[self.ticketPriceArr objectAtIndex:indexPath.row-1];
            cell.ShowQuantity.text=[self.ticketQuantityArr objectAtIndex:indexPath.row-1];
            cell.typeOfTicket.text=[self.ticketTypeArr objectAtIndex:indexPath.row-1];
        }
        if (self.tableDatalist.count-1==indexPath.row) {
            cell.priceLabel.text=@"";
            cell.ShowQuantity.text=@"";
            cell.typeOfTicket.text=@"";
        }

    }
    
    return cell;
}




-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
