//
//  ImageViewCustomCell.h
//  Anypic
//
//  Created by Globussoft 1 on 9/2/14.
//
//

#import <UIKit/UIKit.h>

@interface ImageViewCustomCell : UICollectionViewCell
@property(nonatomic,strong)UIImageView *imageView;
@property(nonatomic,strong)UILabel *eventDetailLabel;
@property(nonatomic,strong)UILabel *eventTitleLabel;
@end
