//
//  AddMoreOrganizer.m
//  Vconnect
//
//  Created by Globussoft 1 on 6/12/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import "AddMoreOrganizer.h"
#import "TableViewCell.h"
#import "AppDelegate.h"

@interface AddMoreOrganizer ()

@end

@implementation AddMoreOrganizer
@synthesize delegate;

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:YES];
    NSLog(@"detail Array %@",self.orgnDetailArray);
    
    [delegate sendOrganizerDetailArray:self.orgnDetailArray];
}
- (void)viewDidLoad {
    [super viewDidLoad];
   
            self.orgnDetailArray=[[NSMutableArray alloc] init];
            self.nameArray=[[NSMutableArray alloc] init];
            self.emailArray=[[NSMutableArray alloc] init];
            self.descriptionArray=[[NSMutableArray alloc]init];
    

    
    if (IS_IPHONE_6P || IS_IPHONE_6) {
         self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"login_signup_bg@3x.png"]];
    }else{
        self.view.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"after_login_bg_320x480.png"]];

    }
    
    UIBarButtonItem *rightBarItem=[[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(doneButtonAction:)];
    rightBarItem.tintColor=[UIColor whiteColor];
    
    self.navigationController.navigationItem.rightBarButtonItem=rightBarItem;
    [self.navigationItem setRightBarButtonItem:rightBarItem];
    
    self.tableDatalist=[[NSMutableArray alloc]init];
    [self.tableDatalist addObject:@"One"];
//    [self.tableDatalist addObject:@"Two"];
    
    self.tableView=[[UITableView alloc] initWithFrame:CGRectMake(0, 5, self.view.frame.size.width, self.view.frame.size.height-10)];
    self.tableView.delegate=self;
    self.tableView.dataSource=self;
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
     self.tableView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        //  self.tableView.backgroundColor=[UIColor yellowColor];
       [self.view addSubview:self.tableView];

    
    UIButton *createAccount = [UIButton buttonWithType:UIButtonTypeCustom];
    createAccount.frame = CGRectMake(0, 5, self.tableView.frame.size.width, 40);
    createAccount.titleLabel.font = [UIFont systemFontOfSize:20.0f];
    createAccount.backgroundColor=[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1];
    [createAccount setTitle:@"  Add More Organizer Detail"  forState:UIControlStateNormal];
    createAccount.titleLabel.textColor=[UIColor whiteColor];
    [createAccount setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    createAccount.layer.borderColor=[[UIColor whiteColor] CGColor];
    createAccount.layer.borderWidth=1.5;
    
    [createAccount addTarget:self action:@selector(createNewTicket:) forControlEvents:UIControlEventTouchUpInside];
//    static NSString *CellIdentifier = @"OrganizerCell";
    self.tableView.tableFooterView=createAccount;
    self.tableView.tableFooterView.userInteractionEnabled=YES;
//   [self.tableView registerClass:[TableViewCell class] forCellReuseIdentifier:CellIdentifier];

    // Do any additional setup after loading the view.
}

-(void)doneButtonAction:(UIBarButtonItem *)baritem{
    
//    NSLog(@"textfield tag %@",)
    NSIndexPath *index=[NSIndexPath indexPathForRow:self.currentSelectedIndex inSection:0];
    
    TableViewCell *cell=(TableViewCell *)[self.tableView cellForRowAtIndexPath:index];
    [cell.orgnDiscriptionTxtFld resignFirstResponder];
    [cell.orgnEmailTxtFld resignFirstResponder];
    [cell.orgnNameTxtFld resignFirstResponder];
    
//    if (self.nameArray.count==self.emailArray.count==self.descriptionArray.count) {
        for (int i=0; i<self.nameArray.count; i++) {
            NSMutableDictionary *dict=[[NSMutableDictionary alloc] init];
            [dict setObject:[self.nameArray objectAtIndex:i] forKey:@"organisername"];
             [dict setObject:[self.emailArray objectAtIndex:i] forKey:@"organiseremail"];
             [dict setObject:[self.descriptionArray objectAtIndex:i] forKey:@"organiserdescription"];
            [self.orgnDetailArray insertObject:dict atIndex:i];

        }
       
//   }
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)createNewTicket:(UIButton *)button{
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView beginUpdates];
        [self.tableDatalist insertObject:@"Hello" atIndex:self.tableDatalist.count-1];
        
       
        if (self.tableDatalist.count>9) {
            self.tableView.contentOffset=CGPointMake(0,self.tableView.contentOffset.x+ 200);
        }
        [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:self.tableDatalist.count-1 inSection:0]]
                              withRowAnimation:UITableViewRowAnimationRight];
        
        
        [self.tableView endUpdates];
    });
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.tableDatalist.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPat
{

    return 280.0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *CellIdentifier = @"OrganizerCell";
    TableViewCell *cell = (TableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[TableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.orgnDiscriptionTxtFld.delegate=self;
        cell.orgnEmailTxtFld.delegate=self;
        cell.orgnNameTxtFld.delegate=self;
        cell.orgnNameTxtFld.tag=indexPath.row;
        cell.orgnEmailTxtFld.tag=indexPath.row;
        cell.orgnDiscriptionTxtFld.tag=indexPath.row;
         cell.orgnDiscriptionTxtFld.editable = YES;
        [cell.orgnDiscriptionTxtFld setUserInteractionEnabled:YES];
    }else{
        if (indexPath.row<self.nameArray.count) {
            cell.orgnNameTxtFld.text=[self.nameArray objectAtIndex:indexPath.row];
            cell.orgnEmailTxtFld=[self.emailArray objectAtIndex:indexPath.row];
            cell.orgnDiscriptionTxtFld=[self.descriptionArray objectAtIndex:indexPath.row];
        }else{
            cell.orgnDiscriptionTxtFld.delegate=self;
            cell.orgnEmailTxtFld.delegate=self;
            cell.orgnNameTxtFld.delegate=self;

            cell.orgnNameTxtFld.tag=indexPath.row;
            cell.orgnEmailTxtFld.tag=indexPath.row;
            cell.orgnDiscriptionTxtFld.tag=indexPath.row;
        
        }
        
    }

    return cell;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
    
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


-(void)textFieldDidBeginEditing:(UITextField *)textField{
//    NSLog(@"textfield %@",textField.text);
    
    self.currentSelectedIndex=textField.tag;
    NSLog(@"self.tableView.contentOffset.x  %f",self.tableView.contentOffset.y  );
    
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    
    NSIndexPath *index=[NSIndexPath indexPathForRow:self.currentSelectedIndex inSection:0];
    TableViewCell *cell=(TableViewCell *)[self.tableView cellForRowAtIndexPath:index];
    
    if (![textField.text isEqualToString:@""]) {
        
    if (cell.orgnNameTxtFld==textField) {
    [self.nameArray insertObject:textField.text atIndex:self.currentSelectedIndex];
    NSLog(@"textfield %@",[self.nameArray objectAtIndex:self.currentSelectedIndex]);
     }
    if (cell.orgnEmailTxtFld==textField) {
    [self.emailArray insertObject:textField.text atIndex:self.currentSelectedIndex];
        NSLog(@"textfield %@",[self.emailArray objectAtIndex:self.currentSelectedIndex]);

     }
    
    }


}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    return [textField resignFirstResponder];
}

-(void)textViewDidBeginEditing:(UITextView *)textView{
  self.currentSelectedIndex=textView.tag;
      NSLog(@"self.tableView.contentOffset.x  %f",self.tableView.contentOffset.y  );
}
-(void)textViewDidEndEditing:(UITextView *)textView{
    if (![textView.text isEqualToString:@""]) {
    [self.descriptionArray insertObject:textView.text atIndex:self.currentSelectedIndex];
       
   
        
    }
     NSLog(@"textview %@",[self.descriptionArray objectAtIndex:self.currentSelectedIndex]);
}
-(void)textViewDidChange:(UITextView *)textView{

}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
         [textView resignFirstResponder];
        return YES;
    }

    return YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
