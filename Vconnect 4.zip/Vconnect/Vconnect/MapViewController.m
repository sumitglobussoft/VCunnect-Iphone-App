//
//  MapViewController.m
//  Vconnect
//
//  Created by Globussoft 1 on 6/10/15.
//  Copyright (c) 2015 globussoft. All rights reserved.
//

#import "MapViewController.h"
#import "Place.h"
#import "PlaceMark.h"
#import "UserDefaultHelper.h"


@interface MapViewController ()

@end

@implementation MapViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.mapUser=[[MKMapView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-50)];
    self.mapUser.delegate=self;
        //    self.mapUser.annotations
    [self.view addSubview:self.mapUser];
    Place* home = [[Place alloc] init];
    home.name = @"It's me";
    home.description = @"";
    home.latitude = [[[UserDefaultHelper sharedObject] currentLatitude] doubleValue];
    home.longitude = [[[UserDefaultHelper sharedObject] currentLongitude] doubleValue];
    PlaceMark* markPickUp = [[PlaceMark alloc] initWithPlace:home];
    [self.mapUser addAnnotation:markPickUp];
    MKCoordinateRegion region;
    region.center.latitude     = home.latitude;
    region.center.longitude    = home.longitude;
    region.span.latitudeDelta  = 0.1;
    region.span.longitudeDelta = 0.1;
   [self.mapUser setRegion:region animated:YES];
    
    CLLocationCoordinate2D center = {home.latitude, home.longitude};
    

        // Add an overlay
    MKCircle *circle = [MKCircle circleWithCenterCoordinate:center radius:500];
    [self.mapUser addOverlay:circle];
//    [self.mapUser setUserTrackingMode:MKUserTrackingModeFollow];

    // Do any additional setup after loading the view.
}

- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id<MKOverlay>)overlay
{
    MKCircleView *circleView = [[MKCircleView alloc] initWithOverlay:overlay];
    [circleView setFillColor:[UIColor colorWithRed:(CGFloat)255/255 green:(CGFloat)255/255 blue:(CGFloat)153/255 alpha:1]];
    [circleView setStrokeColor:[UIColor colorWithRed:(CGFloat)26/255 green:(CGFloat)147/255 blue:(CGFloat)131/255 alpha:1]];
    [circleView setAlpha:0.5f];
   
    return circleView;
}


#pragma mark-
#pragma mark MapView Delegate

- (MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation
{
//    PlaceMark *place=(PlaceMark *)annotation;
    MKPinAnnotationView *newAnnotation = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"PlaceMark"];

        newAnnotation.image=[UIImage imageNamed:@"User + Z 6.png"];
    
    newAnnotation.canShowCallout = YES;
    return newAnnotation;
}


- (void)mapView:(MKMapView *)mapView didSelectAnnotationView:(MKAnnotationView *)view
{
    
}

- (void)mapView:(MKMapView *)mapView didDeselectAnnotationView:(MKAnnotationView *)view
{
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
