//
//  LogutVC.h
//  UberValetService
//
//  Created by Globussoft 1 on 11/25/14.
//  Copyright (c) 2014 Globussoft 1. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LogutVC : UIViewController
//@property (strong, nonatomic) AppDelegateFirstVC *viewController ;
@property (strong, nonatomic) UIWindow *window;
@end
